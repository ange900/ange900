#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Moteur EPG — côté SERVEUR, sans navigateur.

POURQUOI CE FICHIER EXISTE
==========================

Le panel savait déjà associer une chaîne à son guide : `src/auto/` le fait,
dans le navigateur, quand on ouvre l'écran EPG. C'est insuffisant. Une grille
doit se remplir alors que personne ne regarde — la nuit, après un
redémarrage, pendant les vacances de l'exploitant.

Ce module fait donc tourner la MÊME décision côté serveur. « La même » n'est
pas une figure de style : le barème ci-dessous est le port ligne à ligne de
`frontend-modern/src/auto/score.js`, et `tests/epg/essai-parite-moteur.mjs`
fait passer une table d'épreuves aux deux implémentations et exige des
verdicts identiques. Le jour où l'une dérive, ce test tombe.

CE QUE FAIT L'AMONT, ET CE QU'IL NE FAIT PAS
============================================

Mesuré, pas supposé :

  o11-rebuild   Son job natif `epg.refresh` télécharge le XMLTV, le valide, le
                REMPLACE en une transaction, purge, puis appelle son propre
                `AutoMapper` (qui préserve les mappings manuels) et applique
                les logos XMLTV. Tout est déjà là. Il ne lui manque QUE la
                planification.
                → on crée l'horaire, et le binaire fait le reste. Même panel
                  arrêté. C'est le niveau 1 de la préférence de l'exploitant.

  O11 Pro       `EpgAutorefresh` + `EpgRefreshCron` existent par provider, mais
                ils pilotent le SCRIPT du provider : sans script, l'amont
                répond « no script specified ». Et surtout O11 Pro n'associe
                RIEN tout seul : `EpgId` se remplit à la main, flux par flux.
                → le rafraîchissement natif est activé quand il a un sens, et
                  l'association est faite ici, par un fil du panel. C'est le
                  niveau 4, choisi parce que les niveaux 1 à 3 n'existent pas
                  de ce côté — pas parce qu'il était plus commode.

CE QUI N'EST JAMAIS ÉCRIT DANS LES JOURNAUX
===========================================

Aucun mot de passe, aucun jeton, aucun cookie, aucun en-tête d'autorisation.
`_sans_secret()` est la seule porte de sortie du texte, et elle est appelée
sur tout ce qui vient de l'amont.
"""

import gzip
import json
import os
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

# ─────────────────────────────────────────────────────────────────────────────
# 1. LE BARÈME — miroir exact de frontend-modern/src/auto/score.js
#
# Toute retouche ici doit être faite là-bas aussi. Le test de parité est là
# pour que « doit » devienne « sera ».
# ─────────────────────────────────────────────────────────────────────────────

MARQUEURS = [
    "hd", "fhd", "uhd", "sd", "4k", "8k",
    "hevc", "h265", "h264", "avc", "ac3", "aac",
    "fr", "vf", "vo", "vost",
    "backup", "feed", "raw", "test", "alt",
]

POINTS = {
    "ID_EXACT": 100,       # l'identifiant du guide est celui du flux : un fait
    "NOM_EXACT": 90,       # même nom, à la casse près
    "ALIAS_EXACT": 85,     # un alias déclaré par l'exploitant
    "NOM_NORMALISE": 80,   # même nom, marqueurs de qualité retirés
    "BONUS_PROVIDER": 10,  # le candidat porte la marque du provider du flux
}

SEUIL = 85


def _sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def normaliser(nom):
    """Une clé de comparaison. JAMAIS un nom d'affichage.

    On ne retire que des MOTS ENTIERS : retirer « fr » comme sous-chaîne
    ferait de « FRANCE 2 » un « ance 2 », et deux chaînes différentes
    finiraient par se ressembler — l'accident précis qu'on évite.
    """
    if not nom:
        return ""
    s = _sans_accents(str(nom).lower())
    s = s.replace("+", " plus ").replace("&", " et ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    mots = [m for m in s.split(" ") if m and m not in MARQUEURS]
    return " ".join(mots).strip()


def nom_exact(nom):
    return re.sub(r"\s+", " ", str(nom or "").strip().lower())


def id_comparable(ident):
    return str(ident or "").strip().lower()


def scorer(flux, candidat):
    raisons = []
    score = 0

    id_flux = id_comparable(flux.get("EpgId"))
    if id_flux and id_comparable(candidat.get("id")) == id_flux:
        score = POINTS["ID_EXACT"]
        raisons.append("epg-id exact")
    else:
        noms = [x for x in (nom_exact(n) for n in candidat.get("noms") or []) if x]
        alias = [x for x in (nom_exact(a) for a in candidat.get("alias") or []) if x]
        cible = nom_exact(flux.get("Name"))
        cible_n = normaliser(flux.get("Name"))

        if cible and cible in noms:
            score = POINTS["NOM_EXACT"]
            raisons.append("nom exact")
        elif cible and cible in alias:
            score = POINTS["ALIAS_EXACT"]
            raisons.append("alias exact")
        elif cible_n and any(normaliser(n) == cible_n for n in candidat.get("noms") or []):
            score = POINTS["NOM_NORMALISE"]
            raisons.append("nom normalisé")
        elif cible_n and any(normaliser(a) == cible_n for a in candidat.get("alias") or []):
            score = POINTS["NOM_NORMALISE"]
            raisons.append("alias normalisé")

    # Le bonus ne s'applique QU'À un candidat déjà retenu : sans ce garde-fou,
    # tous les candidats d'un même guide gagneraient dix points et le bonus ne
    # discriminerait plus rien.
    if score > 0 and flux.get("ProviderId") and candidat.get("provider"):
        if id_comparable(candidat["provider"]) == id_comparable(flux["ProviderId"]):
            score += POINTS["BONUS_PROVIDER"]
            raisons.append("provider confirmé")

    return {"score": score, "raison": " + ".join(raisons)}


def choisir(flux, candidats):
    """Rend EXACTEMENT ce que rend `choisir` de score.js — y compris la forme :
    `{"choix": {"candidat", "score", "raison"}, "motif"}`. La forme fait partie
    du contrat autant que le verdict ; `essai-parite-moteur.mjs` compare les
    deux."""
    notes = []
    for c in candidats or []:
        n = scorer(flux, c)
        if n["score"] > 0:
            notes.append({"candidat": c, "score": n["score"], "raison": n["raison"]})
    if not notes:
        return {"choix": None, "motif": "aucun candidat"}

    notes.sort(key=lambda n: -n["score"])
    meilleur = notes[0]
    if meilleur["score"] < SEUIL:
        return {"choix": None,
                "motif": "score %d < %d (%s)" % (meilleur["score"], SEUIL, meilleur["raison"])}

    # Deux candidats à égalité au sommet : on ne tranche pas. Choisir serait
    # tirer au sort, et un tirage au sort finit par associer un logo faux à
    # une chaîne juste. Le motif NOMME les prétendants — c'est ce qu'on lit
    # quand on vient corriger l'ambiguïté à la main.
    exaequo = [n for n in notes
               if n["score"] == meilleur["score"]
               and id_comparable(n["candidat"].get("id")) != id_comparable(meilleur["candidat"].get("id"))]
    if exaequo:
        noms = ", ".join(str(n["candidat"].get("id")) for n in [meilleur] + exaequo)
        return {"choix": None,
                "motif": "ambigu : %d candidats à %d (%s)"
                         % (len(exaequo) + 1, meilleur["score"], noms)}

    return {"choix": meilleur, "motif": meilleur["raison"]}


# ─────────────────────────────────────────────────────────────────────────────
# 2. LE GUIDE — lecture d'un XMLTV
# ─────────────────────────────────────────────────────────────────────────────

MAX_GUIDE = 128 * 1024 * 1024   # au-delà, ce n'est plus un guide, c'est une fuite
_ENTITE = re.compile(rb"<!ENTITY", re.I)


class GuideRefuse(Exception):
    """Le guide n'a pas été lu — et on dit pourquoi plutôt que rendre []."""


def marque_provider(id_chaine, provider_id):
    """Le miroir de `marqueProvider` de guide.js.

    Le bonus de provider ne vaut QUE si le candidat porte vraiment la marque du
    provider. Estampiller « sonde » sur les 112 chaînes du guide de « sonde »
    donnerait dix points à tout le monde : le bonus ne discriminerait plus
    rien, et — plus grave — le seuil de 85 tomberait en pratique à 75, ce qui
    suffit à faire passer une correspondance par nom NORMALISÉ (80) que le
    barème refuse exprès.
    """
    ident = id_comparable(id_chaine)
    p = id_comparable(provider_id)
    if not ident or not p:
        return ""
    if ident == p:
        return provider_id
    return provider_id if any(ident.startswith(p + sep) for sep in ("_", ".", "-", ":")) else ""


def analyser_xmltv(donnees, provider=""):
    """Rend le catalogue des `<channel>`. Les programmes ne servent pas à
    l'association : inutile de garder des mégaoctets en mémoire pour trois
    attributs.

    Un DOCTYPE est toléré — Go comme Python ne résolvent aucune DTD externe —
    mais un DOCTYPE contenant `<!ENTITY` est refusé net : c'est la forme d'une
    XXE, et aucun guide honnête n'en a besoin.
    """
    if not donnees:
        raise GuideRefuse("guide vide")
    if len(donnees) > MAX_GUIDE:
        raise GuideRefuse("guide trop volumineux (%d octets)" % len(donnees))
    if donnees[:2] == b"\x1f\x8b":
        try:
            donnees = gzip.decompress(donnees)
        except OSError as e:
            raise GuideRefuse("gzip illisible : %s" % e)
    tete = donnees[:4096]
    if _ENTITE.search(tete):
        raise GuideRefuse("DOCTYPE avec <!ENTITY refusé")
    try:
        racine = ET.fromstring(donnees)
    except ET.ParseError as e:
        raise GuideRefuse("XML invalide : %s" % e)

    chaines = []
    for el in racine.iter("channel"):
        ident = (el.get("id") or "").strip()
        if not ident:
            continue
        noms = [(n.text or "").strip() for n in el.findall("display-name")]
        noms = [n for n in noms if n]
        icone = ""
        ic = el.find("icon")
        if ic is not None:
            icone = (ic.get("src") or "").strip()
        chaines.append({"id": ident, "noms": noms, "alias": [],
                        "icone": icone, "provider": marque_provider(ident, provider)})
    return chaines


def logo_utilisable(url):
    """Une adresse de logo n'est acceptée que si c'en est une. Un `src` vide,
    relatif ou en `javascript:` n'a rien à faire dans un champ que le panel
    affichera."""
    return bool(url) and bool(re.match(r"^https?://\S+$", str(url).strip(), re.I))


# ─────────────────────────────────────────────────────────────────────────────
# 3. LE JOURNAL — ce que le moteur a écrit, et ce qu'il n'a pas le droit de
#    toucher
#
# O11 Pro n'a AUCUN champ qui distingue « associé à la main » de « associé
# automatiquement ». Sans mémoire, le moteur écraserait au premier passage le
# choix que l'exploitant venait de faire. Le journal est cette mémoire, et il
# est sur disque : la protection survit à un redémarrage, qui est justement le
# moment où l'on serait tenté de tout refaire.
#
# La règle tient en trois lignes :
#
#   EpgId vide                            → LIBRE   : le moteur peut écrire
#   EpgId == ce que le moteur a écrit     → À NOUS  : le moteur peut corriger
#   EpgId présent et différent (ou inconnu) → MANUEL : on n'y touche JAMAIS
#
# Un champ vidé redevient libre : un champ vide n'est pas une association.
# ─────────────────────────────────────────────────────────────────────────────

LIBRE, A_NOUS, MANUEL = "libre", "moteur", "manuel"


class Journal:
    def __init__(self, chemin):
        self.chemin = chemin
        self._verrou = threading.Lock()
        self.donnees = {"version": 1, "providers": {}, "passes": {}}
        self.charger()

    def charger(self):
        try:
            with open(self.chemin, "r", encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict) and isinstance(d.get("providers"), dict):
                self.donnees = {"version": d.get("version", 1),
                                "providers": d["providers"],
                                "passes": d.get("passes") or {}}
        except (OSError, ValueError):
            pass  # journal absent ou illisible : on repart d'une page blanche,
                  # ce qui est sûr — tout EpgId déjà posé sera vu comme MANUEL.

    def enregistrer(self):
        """Écriture atomique : un journal à moitié écrit ferait perdre la
        distinction manuel/automatique, donc les choix de l'exploitant."""
        tmp = self.chemin + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.chemin) or ".", exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.donnees, f, ensure_ascii=False, indent=1, sort_keys=True)
            os.chmod(tmp, 0o600)
            os.replace(tmp, self.chemin)
        except OSError:
            pass

    def proprietaire(self, provider, flux_id, epg_id_actuel):
        epg = id_comparable(epg_id_actuel)
        if not epg:
            return LIBRE
        note = (self.donnees["providers"].get(provider) or {}).get(flux_id)
        if note and id_comparable(note.get("epg_id")) == epg:
            return A_NOUS
        return MANUEL

    def noter(self, provider, flux_id, epg_id, logo, score, raison):
        with self._verrou:
            self.donnees["providers"].setdefault(provider, {})[flux_id] = {
                "epg_id": epg_id, "logo": logo, "score": score,
                "raison": raison, "quand": int(time.time()),
            }

    def note_de_passe(self, provider, rapport):
        with self._verrou:
            self.donnees["passes"][provider] = rapport

    def derniere_passe(self, provider=None):
        if provider:
            return self.donnees["passes"].get(provider)
        return dict(self.donnees["passes"])


# ─────────────────────────────────────────────────────────────────────────────
# 4. LES VERROUS — jamais deux passes sur le même provider
# ─────────────────────────────────────────────────────────────────────────────

class Verrous:
    """Un verrou par provider, non bloquant.

    Non bloquant est le point : si une passe tourne déjà, la seconde demande
    ne fait pas la queue derrière — elle renonce et le dit. Faire la queue
    finirait par empiler six heures de passes en retard sur un amont lent.
    """

    def __init__(self):
        self._m = threading.Lock()
        self._pris = {}

    def prendre(self, cle):
        with self._m:
            if self._pris.get(cle):
                return False
            self._pris[cle] = time.time()
            return True

    def liberer(self, cle):
        with self._m:
            self._pris.pop(cle, None)

    def occupes(self):
        with self._m:
            return dict(self._pris)


# ─────────────────────────────────────────────────────────────────────────────
# 5. PARLER À L'AMONT
# ─────────────────────────────────────────────────────────────────────────────

_SECRET = re.compile(
    r"(?i)(token|password|passwd|pwd|authorization|cookie|bearer|jeton|key)"
    r"\s*[=:]\s*[^\s&\"',;]+")


def _sans_secret(texte):
    """La seule porte de sortie du texte venu de l'amont. Un jeton apparaît
    dans une URL de guide aussi souvent que dans un en-tête ; il ne doit
    apparaître dans aucun journal."""
    return _SECRET.sub(lambda m: m.group(0).split(m.group(0)[len(m.group(1))], 1)[0] + "=…",
                       str(texte or ""))[:600]


class ClientLegacy:
    """O11 Pro : tout en POST, jeton brut dans `Authorization`, et des
    réponses gzippées sans que personne l'ait demandé."""

    def __init__(self, hote, port, jeton, delai=30):
        self.base = "http://%s:%d" % (hote, port)
        self.jeton = jeton
        self.delai = delai

    def _ouvrir(self, chemin, corps=None, methode="POST"):
        url = self.base + chemin
        donnees = json.dumps(corps or {}).encode() if methode == "POST" else None
        req = urllib.request.Request(url, data=donnees, method=methode)
        req.add_header("Authorization", self.jeton)
        req.add_header("Accept-Encoding", "gzip")
        if donnees is not None:
            req.add_header("Content-Type", "application/json")
        rep = urllib.request.urlopen(req, timeout=self.delai)
        brut = rep.read()
        if rep.headers.get("Content-Encoding", "").lower() == "gzip":
            brut = gzip.decompress(brut)
        return rep, brut

    def api(self, chemin, corps=None):
        _, brut = self._ouvrir("/api" + chemin, corps)
        try:
            return json.loads(brut.decode("utf-8", "replace"))
        except ValueError:
            raise GuideRefuse("réponse non-JSON de %s" % chemin)

    def brut(self, chemin):
        _, b = self._ouvrir(chemin, methode="GET")
        return b

    # -- les trois appels dont le moteur a besoin, et rien de plus ------------

    def providers(self):
        return (self.api("/provider/get", {}) or {}).get("Providers") or []

    def flux(self, provider, type_="linear"):
        d = self.api("/stream/get", {"ProviderId": provider, "Type": type_}) or {}
        return d.get("Streams") or [], bool(d.get("HasEpg"))

    def ecrire_flux(self, provider, flux):
        """Le contrat RÉEL, relevé sur le binaire : `StreamId` à côté de
        `Stream`, et PAS de `Type`. Envoyer `Type` à la place de `StreamId`
        rend « stream not found » — un 404 poli qui n'écrit rien et qu'on peut
        prendre longtemps pour un succès si on ne relit pas."""
        return self.api("/stream/edit", {"ProviderId": provider,
                                         "StreamId": flux.get("Id"),
                                         "Stream": flux})

    def rafraichir_epg(self, provider):
        return self.api("/epg/refresh", {"ProviderId": provider})


# ─────────────────────────────────────────────────────────────────────────────
# 6. LES DEUX PASSES
# ─────────────────────────────────────────────────────────────────────────────

CHEMINS_GUIDE = ("/epg/%s.xml.gz", "/epg/%s.xml", "/epg/all.xml.gz", "/epg/all.xml")


def _guide_du_serveur(client, provider, journaliser):
    """Le guide vient du SERVEUR lui-même, jamais d'un service tiers. Une base
    de logos codée en dur serait une adresse qu'on ne contrôle pas, qui change
    sans prévenir, et qui associerait un jour un logo faux à une chaîne
    juste."""
    dernier = ""
    for gabarit in CHEMINS_GUIDE:
        chemin = gabarit % urllib.parse.quote(provider) if "%s" in gabarit else gabarit
        try:
            brut = client.brut(chemin + "?token=" + urllib.parse.quote(client.jeton))
            chaines = analyser_xmltv(brut, provider)
            if chaines:
                journaliser("guide lu : %s → %d chaînes" % (chemin, len(chaines)))
                return chaines, chemin
            dernier = "%s : 0 chaîne" % chemin
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, GuideRefuse) as e:
            dernier = "%s : %s" % (chemin, _sans_secret(e))
    raise GuideRefuse(dernier or "aucun guide")


def passe_legacy(client, provider_id, journal, journaliser, simuler=False,
                 types=("linear", "event")):
    """Une passe complète sur un provider O11 Pro.

    Elle ne remplace RIEN tant qu'elle n'a pas un guide valide en main : si le
    téléchargement ou l'analyse échoue, on sort sans écrire, et le guide, les
    mappings et les logos précédents restent exactement ce qu'ils étaient.
    """
    rapport = {"provider": provider_id, "quand": int(time.time()),
               "associes": 0, "corriges": 0, "logos": 0, "manuels_preserves": 0,
               "sans_candidat": 0, "ambigus": 0, "sous_seuil": 0,
               "erreur": "", "simule": bool(simuler), "guide": "", "chaines_guide": 0}

    # (a) Le rafraîchissement natif d'abord — s'il a un sens de ce côté.
    try:
        prov = next((p for p in client.providers() if p.get("Id") == provider_id), None)
    except Exception as e:
        rapport["erreur"] = "providers illisibles : %s" % _sans_secret(e)
        return rapport
    if prov is None:
        rapport["erreur"] = "provider inconnu"
        return rapport
    if prov.get("Script") and not simuler:
        try:
            client.rafraichir_epg(provider_id)
            journaliser("rafraîchissement natif demandé (le provider a un script)")
        except Exception as e:
            journaliser("rafraîchissement natif refusé : %s" % _sans_secret(e))

    # (b) Le guide. Rien ne s'écrit avant de l'avoir.
    try:
        candidats, chemin = _guide_du_serveur(client, provider_id, journaliser)
    except GuideRefuse as e:
        rapport["erreur"] = "guide indisponible — rien n'a été modifié (%s)" % _sans_secret(e)
        return rapport
    rapport["guide"] = chemin
    rapport["chaines_guide"] = len(candidats)

    # (c) L'association, flux par flux.
    for type_ in types:
        try:
            flux, _ = client.flux(provider_id, type_)
        except Exception as e:
            journaliser("flux %s illisibles : %s" % (type_, _sans_secret(e)))
            continue

        for f in flux:
            fid = f.get("Id") or ""
            if not fid:
                continue
            proprio = journal.proprietaire(provider_id, fid, f.get("EpgId"))
            if proprio == MANUEL:
                rapport["manuels_preserves"] += 1
                continue

            f2 = dict(f)
            f2["ProviderId"] = provider_id
            # Un flux déjà associé par nous garde son EpgId comme indice, mais
            # c'est le NOM qui décide : le guide a pu changer d'identifiants.
            verdict = choisir(f2, candidats)
            if not verdict["choix"]:
                motif = verdict["motif"]
                if motif.startswith("ambigu"):
                    rapport["ambigus"] += 1
                elif motif.startswith("score"):
                    rapport["sous_seuil"] += 1
                else:
                    rapport["sans_candidat"] += 1
                continue

            meilleur = verdict["choix"]
            c = meilleur["candidat"]
            neuf_epg = c["id"]
            neuf_logo = c.get("icone") if logo_utilisable(c.get("icone")) else ""

            change = {}
            if id_comparable(f.get("EpgId")) != id_comparable(neuf_epg):
                change["EpgId"] = neuf_epg
            # Le logo ne s'écrase que s'il est VIDE ou s'il vient de nous : un
            # logo posé à la main est un choix, pas un trou à combler.
            note = (journal.donnees["providers"].get(provider_id) or {}).get(fid) or {}
            logo_actuel = (f.get("LogoUrl") or "").strip()
            logo_a_nous = logo_actuel and logo_actuel == (note.get("logo") or "")
            if neuf_logo and (not logo_actuel or logo_a_nous) and logo_actuel != neuf_logo:
                change["LogoUrl"] = neuf_logo

            if not change:
                continue
            if simuler:
                if "EpgId" in change:
                    rapport["corriges" if proprio == A_NOUS else "associes"] += 1
                if "LogoUrl" in change:
                    rapport["logos"] += 1
                continue

            envoi = dict(f)
            envoi.update(change)
            try:
                client.ecrire_flux(provider_id, envoi)
            except Exception as e:
                journaliser("écriture refusée sur %s : %s" % (fid, _sans_secret(e)))
                continue
            if "EpgId" in change:
                rapport["corriges" if proprio == A_NOUS else "associes"] += 1
            if "LogoUrl" in change:
                rapport["logos"] += 1
            journal.noter(provider_id, fid, neuf_epg,
                          change.get("LogoUrl", note.get("logo") or ""),
                          meilleur["score"], verdict["motif"])

    if not simuler:
        journal.enregistrer()
    return rapport


# ── o11-rebuild : on ne fait pas le travail, on l'ALLUME ─────────────────────

def assurer_planification_rebuild(adaptateur, session, intervalle, journaliser):
    """Crée l'horaire natif `epg.refresh` pour chaque source EPG active.

    C'est tout ce qu'il y a à faire de ce côté, et c'est délibéré : le binaire
    sait déjà télécharger, valider, remplacer en transaction, purger,
    ré-associer en préservant les mappings manuels, et reprendre les logos. Le
    refaire ici donnerait un second moteur qui pourrait dire autre chose que
    le premier.

    Conséquence heureuse : une fois l'horaire posé, l'automatisation ne dépend
    plus du panel. Le panel peut être arrêté, désinstallé, remplacé.
    """
    rapport = {"crees": 0, "deja": 0, "sources": 0, "erreur": ""}
    try:
        sources = adaptateur._liste(session, "/api/v1/epg/sources")
        horaires = adaptateur._liste(session, "/api/v1/job-schedules")
    except Exception as e:
        rapport["erreur"] = _sans_secret(e)
        return rapport

    # Le DTO du binaire nomme la cible `target_id` et le type `type` — relevé
    # sur `internal/jobs/schedules.go`, pas deviné.
    connus = {str(h.get("target_id")) for h in horaires
              if h.get("type") == "epg.refresh"}

    for s in sources:
        if s.get("enabled") is False or s.get("active") is False:
            continue
        rapport["sources"] += 1
        sid = str(s.get("id"))
        if sid in connus:
            rapport["deja"] += 1
            continue
        try:
            # EXACTEMENT trois champs. o11-rebuild décode avec
            # `DisallowUnknownFields` : un `enabled` en plus, poli et inutile,
            # fait répondre 400 et l'horaire n'est jamais posé. Le schedule
            # naît actif de toute façon.
            adaptateur._appel(session, "POST", "/api/v1/job-schedules", {
                "type": "epg.refresh",
                "target_id": s.get("id"),
                "interval_seconds": int(intervalle),
            })
            rapport["crees"] += 1
            journaliser("horaire natif epg.refresh créé pour la source %s "
                        "(toutes les %d s)" % (sid, intervalle))
        except Exception as e:
            rapport["erreur"] = _sans_secret(e)
    return rapport


# ─────────────────────────────────────────────────────────────────────────────
# 7. LE PLANIFICATEUR
# ─────────────────────────────────────────────────────────────────────────────

INTERVALLE_DEFAUT = 6 * 3600


class Planificateur(threading.Thread):
    """Le fil qui fait tourner tout ça sans que personne n'ouvre rien.

    Il démarre avec le panel, fait une première passe peu après (le temps que
    l'amont finisse de se lever), puis toutes les six heures. Il ne meurt pas
    sur une erreur d'amont : un serveur redémarré ne doit pas emporter
    l'automatisation avec lui.
    """

    daemon = True

    def __init__(self, fabrique_client, journal, intervalle=INTERVALLE_DEFAUT,
                 premier_delai=45, journaliser=None, mode="legacy",
                 adaptateur=None, session_admin=None):
        super().__init__(name="epg-auto")
        # « legacy »  : le panel fait l'association lui-même, parce qu'O11 Pro
        #               ne sait pas la faire.
        # « rebuild » : le panel ne fait RIEN d'autre qu'allumer l'horaire
        #               natif. Le binaire sait déjà tout faire, et un second
        #               moteur pourrait dire autre chose que le premier.
        self.mode = mode
        self.adaptateur = adaptateur
        self.session_admin = session_admin
        self.fabrique_client = fabrique_client
        self.journal = journal
        self.intervalle = int(intervalle)
        self.premier_delai = premier_delai
        self.verrous = Verrous()
        self._reveil = threading.Event()
        self._stop = threading.Event()
        self.dernier_cycle = {}
        self._log = journaliser or (lambda m: print("[epg-auto] %s" % m, flush=True))

    def journaliser(self, message):
        self._log(_sans_secret(message))

    def reveiller(self):
        self._reveil.set()

    def arreter(self):
        self._stop.set()
        self._reveil.set()

    def run(self):
        self._reveil.wait(self.premier_delai)
        while not self._stop.is_set():
            self._reveil.clear()
            try:
                self.cycle()
            except Exception as e:  # un fil qui meurt éteint l'automatisation
                self.journaliser("cycle interrompu : %s" % _sans_secret(e))
            self._reveil.wait(self.intervalle)

    def cycle(self, provider=None, simuler=False):
        if self.mode == "rebuild":
            return self._cycle_rebuild(simuler)
        client = self.fabrique_client()
        if client is None:
            self.dernier_cycle = {"quand": int(time.time()), "actif": False,
                                  "motif": "identifiants de service non configurés"}
            self.journaliser("inactif : aucun identifiant de service — "
                             "voir O11_AUTO_TOKEN")
            return self.dernier_cycle

        rapports = {}
        try:
            provs = [p.get("Id") for p in client.providers() if p.get("Id")]
        except Exception as e:
            self.dernier_cycle = {"quand": int(time.time()), "actif": True,
                                  "motif": "amont injoignable : %s" % _sans_secret(e)}
            return self.dernier_cycle
        if provider:
            provs = [p for p in provs if p == provider]

        for pid in provs:
            if not self.verrous.prendre(pid):
                rapports[pid] = {"provider": pid, "erreur": "passe déjà en cours"}
                continue
            try:
                r = passe_legacy(client, pid, self.journal,
                                 self.journaliser, simuler=simuler)
                rapports[pid] = r
                if not simuler:
                    self.journal.note_de_passe(pid, r)
                self.journaliser(
                    "%s : %d associés, %d corrigés, %d logos, %d manuels préservés%s"
                    % (pid, r["associes"], r["corriges"], r["logos"],
                       r["manuels_preserves"],
                       (" — " + r["erreur"]) if r["erreur"] else ""))
            finally:
                self.verrous.liberer(pid)

        if not simuler:
            self.journal.enregistrer()
        self.dernier_cycle = {"quand": int(time.time()), "actif": True,
                              "providers": rapports, "intervalle": self.intervalle}
        return self.dernier_cycle


    def _cycle_rebuild(self, simuler=False):
        """Devant o11-rebuild : on pose l'horaire, et on s'efface.

        Ce cycle est volontairement pauvre. Toute richesse ajoutée ici serait
        un deuxième moteur EPG en concurrence avec celui du binaire — et deux
        moteurs qui associent, c'est un jour où ils n'associent pas pareil.
        """
        session = self.session_admin() if callable(self.session_admin) else self.session_admin
        if self.adaptateur is None or session is None:
            self.dernier_cycle = {
                "quand": int(time.time()), "actif": False, "mode": "rebuild",
                "motif": "aucune session administrateur : l'horaire natif sera "
                         "posé à la première connexion, puis le binaire tournera "
                         "seul"}
            return self.dernier_cycle
        if simuler:
            return {"quand": int(time.time()), "actif": True, "mode": "rebuild",
                    "simule": True, "motif": "aucune écriture en simulation"}
        r = assurer_planification_rebuild(self.adaptateur, session,
                                          self.intervalle, self.journaliser)
        self.dernier_cycle = {"quand": int(time.time()), "actif": not r["erreur"],
                              "mode": "rebuild", "planification": r,
                              "intervalle": self.intervalle,
                              "motif": r["erreur"] or
                                       "horaire natif en place : le binaire "
                                       "rafraîchit et ré-associe seul"}
        return self.dernier_cycle


# ─────────────────────────────────────────────────────────────────────────────
# 8. EN LIGNE DE COMMANDE — c'est ainsi que le test « sans navigateur » se fait
# ─────────────────────────────────────────────────────────────────────────────

def _principal(argv):
    import argparse
    a = argparse.ArgumentParser(description="passe EPG automatique, sans navigateur")
    a.add_argument("--hote", default=os.environ.get("O11_UPSTREAM_HOST", "127.0.0.1"))
    a.add_argument("--port", type=int, default=int(os.environ.get("O11_UPSTREAM_PORT", "1337")))
    a.add_argument("--jeton", default=os.environ.get("O11_AUTO_TOKEN", ""))
    a.add_argument("--etat", default=os.environ.get("O11_AUTO_ETAT", "/var/lib/o11-panel/etat-epg.json"))
    a.add_argument("--provider", default="")
    a.add_argument("--simuler", action="store_true")
    a.add_argument("--json", action="store_true")
    o = a.parse_args(argv)

    if not o.jeton:
        print("aucun identifiant de service : --jeton ou O11_AUTO_TOKEN", flush=True)
        return 3

    journal = Journal(o.etat)
    plan = Planificateur(lambda: ClientLegacy(o.hote, o.port, o.jeton), journal)
    res = plan.cycle(provider=o.provider or None, simuler=o.simuler)
    if o.json:
        print(json.dumps(res, ensure_ascii=False, indent=1, sort_keys=True))
    return 0 if res.get("actif") else 3


if __name__ == "__main__":
    import sys
    raise SystemExit(_principal(sys.argv[1:]))
