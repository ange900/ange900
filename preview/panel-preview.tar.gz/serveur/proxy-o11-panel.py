#!/usr/bin/env python3
"""Sert le panel reconstruit devant o11pro, sans toucher au binaire.

Trois règles gouvernent ce fichier.

1. Le partage se fait par une TABLE DE ROUTAGE explicite, jamais par un préfixe
   deviné. Les listes de lecture s'appellent /linear.m3u, /event.m3u, /vod.m3u ;
   les routes de l'interface s'appellent /linear/:provider?, /events/:provider?,
   /vod/:provider?, /epg/:provider?/:stream?. Router sur le préfixe envoie
   l'écran Linear au binaire, qui répond avec SON panel : on croit regarder le
   nouveau et on voit l'ancien, sans la moindre erreur.

2. Une connexion porte PLUSIEURS requêtes. Un navigateur réclame la coquille,
   la feuille de style, le bundle et chaque morceau chargé à la demande sur la
   même connexion persistante. Un proxy qui n'en lit qu'une expédie les
   suivantes à l'amont, qui répond « 401 » sur des fichiers qu'il ne connaît
   pas — et l'écran reste vide sans que rien ne l'explique.

3. Les en-têtes de bout en bout passent intacts. `Authorization`, `Cookie`,
   `Range`, `Content-Type` : en perdre un casse la session, la lecture ou la
   reprise. Seuls les en-têtes de saut (hop-by-hop) sont retirés, parce qu'ils
   décrivent LA CONNEXION et non le message.

Aucune dépendance : bibliothèque standard seulement.
"""

import json
import os
import re
import socket
import socketserver
import sys
import threading
import urllib.parse

VERSION = "@@VERSION@@"

RACINE = os.path.realpath(os.environ.get("O11_PANEL_DIST", "/opt/o11-panel/dist"))
AMONT_HOTE = os.environ.get("O11_UPSTREAM_HOST", "127.0.0.1")
AMONT_PORT = int(os.environ.get("O11_UPSTREAM_PORT", "1337"))
ECOUTE_HOTE = os.environ.get("O11_LISTEN_HOST", "0.0.0.0")
ECOUTE_PORT = int(os.environ.get("O11_LISTEN_PORT", "8080"))

# « o11pro » : l'amont parle l'API legacy, tout est relayé tel quel.
# « rebuild » : l'amont est o11-rebuild, et la couche de compatibilité traduit.
AMONT_TYPE = os.environ.get("O11_UPSTREAM_KIND", "o11pro")

ADAPTATEUR = None
PONT = None
if AMONT_TYPE == "rebuild":
    import importlib.util
    _spec = importlib.util.spec_from_file_location(
        "adaptateur_rebuild",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "adaptateur-rebuild.py"))
    _mod = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
    ADAPTATEUR = _mod.AdaptateurRebuild(AMONT_HOTE, AMONT_PORT)

    _spec_pont = importlib.util.spec_from_file_location(
        "pont_websocket",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "pont-websocket.py"))
    _pont_mod = importlib.util.module_from_spec(_spec_pont)
    _spec_pont.loader.exec_module(_pont_mod)
    PONT = _pont_mod.PontTempsReel(ADAPTATEUR)


# ─────────────────────────────────────────────────────────────────────────────
# AUTO EPG — le moteur qui tourne SANS que personne n'ouvre le navigateur.
#
# Il vit dans le processus du panel, pas dans la page. C'est la différence
# entre « le guide se remplit quand je regarde » et « le guide est rempli
# quand j'arrive ».
# ─────────────────────────────────────────────────────────────────────────────

ETAT_DIR = os.environ.get("O11_PANEL_ETAT", "/var/lib/o11-panel")


def etat_inscriptible(dossier):
    """Le journal EPG doit VRAIMENT pouvoir s'écrire.

    Sous `ProtectSystem=strict`, un service sans `StateDirectory` n'a aucun
    chemin ouvert : `os.makedirs` échoue, et un `except OSError: pass` bien
    intentionné transforme cet échec en perte silencieuse. Ce qui se perd
    n'est pas anodin — c'est la distinction entre « associé à la main » et
    « associé par le moteur », donc la protection des choix de l'exploitant.

    On ne perd rien en silence : on essaie, et on rend la raison.
    """
    try:
        os.makedirs(dossier, mode=0o700, exist_ok=True)
        sonde = os.path.join(dossier, ".ecriture")
        with open(sonde, "w") as f:
            f.write("ok")
        os.unlink(sonde)
        return True, ""
    except OSError as e:
        return False, "%s : %s" % (dossier, e.strerror or e)


ETAT_OK, ETAT_MOTIF = etat_inscriptible(ETAT_DIR)
AUTO_EPG = os.environ.get("O11_AUTO_EPG", "1") not in ("0", "false", "no")
AUTO_INTERVALLE = int(os.environ.get("O11_AUTO_INTERVALLE", str(6 * 3600)))
AUTO_PREMIER = int(os.environ.get("O11_AUTO_PREMIER_DELAI", "45"))

MOTEUR = None
PLAN = None
JOURNAL_EPG = None


def _charger_moteur():
    import importlib.util
    sp = importlib.util.spec_from_file_location(
        "moteur_epg",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "moteur-epg.py"))
    m = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(m)
    return m


class Identifiant:
    """Ce dont le moteur a besoin pour parler à l'amont quand personne n'est là.

    Trois sources, dans cet ordre :

      1. `O11_AUTO_TOKEN` — posé par l'exploitant sur le service. La voie
         propre : rien ne dépend d'une connexion humaine.
      2. Le jeton d'un administrateur qui est passé par le panel, retenu sur
         disque en 0600. Une seule connexion, un jour, suffit alors pour que
         l'automatisation tourne ensuite toute seule — y compris après un
         redémarrage, qui est précisément le moment où l'on croit tout perdu.
      3. Rien — et le moteur le DIT, au lieu de faire semblant de tourner.

    Ce jeton n'est jamais écrit dans un journal, jamais rendu par une route,
    jamais mis dans un message d'erreur.
    """

    def __init__(self, chemin):
        self.chemin = chemin
        self._m = threading.Lock()
        self._jeton = os.environ.get("O11_AUTO_TOKEN", "").strip()
        self.source = "service" if self._jeton else ""
        self.invalide = False
        if not self._jeton:
            try:
                with open(chemin, "r", encoding="utf-8") as f:
                    j = (json.load(f) or {}).get("jeton", "").strip()
                if j:
                    self._jeton, self.source = j, "connexion retenue"
            except (OSError, ValueError):
                pass

    def jeton(self):
        with self._m:
            return self._jeton

    def retenir(self, jeton):
        """Appelé quand un administrateur s'est connecté À TRAVERS le panel."""
        jeton = (jeton or "").strip()
        if not jeton or os.environ.get("O11_AUTO_TOKEN"):
            return
        with self._m:
            # On ne remplace pas un identifiant qui marche : sinon le moteur
            # changerait de compte à chaque visiteur, et finirait par tourner
            # avec les droits du dernier arrivé. On ne remplace que le vide,
            # ou ce que l'amont vient de rejeter.
            if self._jeton and not self.invalide:
                return
            if jeton == self._jeton:
                return
            self.invalide = False
            self._jeton, self.source = jeton, "connexion retenue"
        tmp = self.chemin + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.chemin) or ".", exist_ok=True)
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({"jeton": jeton}, f)
            os.replace(tmp, self.chemin)
        except OSError:
            pass


IDENT = None

if AUTO_EPG:
    try:
        MOTEUR = _charger_moteur()
        JOURNAL_EPG = MOTEUR.Journal(os.path.join(ETAT_DIR, "etat-epg.json"))
        IDENT = Identifiant(os.path.join(ETAT_DIR, "auto-epg.identifiant"))

        def _fabrique_client():
            j = IDENT.jeton()
            if not j:
                return None
            return MOTEUR.ClientLegacy(AMONT_HOTE, AMONT_PORT, j)

        PLAN = MOTEUR.Planificateur(
            _fabrique_client, JOURNAL_EPG,
            intervalle=AUTO_INTERVALLE, premier_delai=AUTO_PREMIER,
            mode="rebuild" if ADAPTATEUR is not None else "legacy",
            adaptateur=ADAPTATEUR,
            # Devant o11-rebuild il faut une session d'administrateur pour
            # POSER l'horaire — une seule fois. Ensuite le binaire tourne seul,
            # panel arrêté compris.
            session_admin=(lambda: next(
                (x for x in list(getattr(ADAPTATEUR, "sessions", {}).values())
                 if getattr(x, "est_admin", False)), None))
            if ADAPTATEUR is not None else None)
    except Exception as _e:  # un moteur en panne ne doit pas retenir le panel
        print("auto EPG indisponible : %s" % _e, flush=True)
        MOTEUR = PLAN = None


def capacites():
    """Ce que le panel peut faire derrière l'amont courant.

    Devant O11 Pro, la couche n'est pas dans le chemin : tout est natif, et le
    dire ainsi évite qu'un écran se restreigne sans raison."""
    if ADAPTATEUR is not None:
        return ADAPTATEUR.capacites()
    return {
        "upstream_kind": "o11pro",
        "adapter_version": None,
        "routes_translated": [],
        "routes_absent": [],
        "playback_urls": "native",
        "notes": ["Amont O11 Pro : le panel parle directement son API, sans "
                  "couche de compatibilité."],
    }

TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".json": "application/json",
    ".map": "application/json",
    ".txt": "text/plain; charset=utf-8",
    ".ttf": "font/ttf",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
}

# ---------------------------------------------------------------------------
# TABLE DE ROUTAGE
#
# Les routes de l'INTERFACE, telles que le routeur du panel les déclare. Elles
# restent au panel, quoi qu'il arrive : plusieurs d'entre elles portent le même
# préfixe qu'un point d'entrée du binaire.
ROUTES_UI = (
    "/login",
    "/providers",
    "/provider",      # /provider/:provider?/:type?/config
    "/linear",
    "/events",
    "/vod",
    "/recordings",
    "/epg",           # collision avec /epg/<provider>.xml.gz — l'extension tranche
    "/monitoring",
    "/logs",
    "/jobs",
    "/search",
    "/servers",
    "/users",
    "/help",
)

# Les points d'entrée du BINAIRE, par préfixe. Aucun d'eux n'est une route de
# l'interface : la liste ci-dessus a été comparée à celle-ci, une à une.
PREFIXES_AMONT = ("/api", "/ws", "/logos", "/static", "/stream", "/replay",
                  # o11-rebuild sert la lecture sous `/output/`. Mesuré :
                  # sans cookie il répond 401, avec la session 200. Le panel
                  # relaie donc ces requêtes AVEC la session de l'appelant —
                  # la même chaîne d'authentification que pour `/api/`, et
                  # certainement pas un contournement : c'est rebuild qui
                  # autorise, comme pour tout le reste.
                  "/output")

# Les ressources servies par le binaire se reconnaissent à leur EXTENSION —
# c'est ce qui permet à /epg/all.xml.gz de partir à l'amont alors que
# /epg/mon-provider reste au panel.
RESSOURCE = re.compile(r"\.(m3u|m3u8|conf|xml|gz|ts|mp4|xspf|strm|py)(\?|$)")

# Le panel lui-même vit sous /static/assets/, que le binaire ne connaît pas.
PANEL_ASSETS = "/static/assets/"

# Une RESSOURCE ne doit jamais recevoir la coquille SPA. Rendre `index.html`
# avec un code 200 sur une image absente est le pire des deux mondes : le
# navigateur croit avoir reçu un PNG, décode du HTML, et n'affiche rien — sans
# la moindre erreur pour dire pourquoi. Un 404 est franc et se voit.
#
# La liste porte les extensions que le panel lui-même sert ou référence.
EXTENSIONS_FICHIER = (
    ".js", ".mjs", ".css", ".map",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".json", ".txt", ".webmanifest",
)


def est_fichier(chemin):
    nu = chemin.split("?")[0]
    return nu.lower().endswith(EXTENSIONS_FICHIER)

# En-têtes de saut : ils décrivent la connexion, pas le message. Les relayer
# fait mentir l'autre bout sur l'état de SA connexion.
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailer", "transfer-encoding", "upgrade",
}

MAX_ENTETE = 262144


def est_route_ui(chemin):
    nu = chemin.split("?")[0]
    for r in ROUTES_UI:
        if nu == r or nu.startswith(r + "/"):
            return True
    return False


def pour_amont(chemin):
    """La décision de routage, en un seul endroit."""
    nu = chemin.split("?")[0]
    if nu.startswith(PANEL_ASSETS):
        return False                      # le panel, que le binaire ignore
    # Devant o11-rebuild, `/static/` n'existe PAS : l'y envoyer ne rapporte que
    # sa propre coquille SPA, en 200 et en text/html. Le panel sert donc ses
    # fichiers lui-même, et rend un 404 franc quand il n'en a pas.
    # Devant O11 Pro, au contraire, `/static/` porte ses icônes, `o11.py` et
    # `example.py` : on continue de les relayer.
    if ADAPTATEUR is not None and nu.startswith("/static/"):
        return False
    if RESSOURCE.search(chemin):
        return True                       # une ressource du serveur
    if any(nu == p or nu.startswith(p + "/") or nu == p + "" for p in PREFIXES_AMONT):
        return True
    if est_route_ui(chemin):
        return False                      # une route de l'interface
    return False                          # tout le reste : repli SPA


def pomper(source, cible):
    try:
        while True:
            d = source.recv(65536)
            if not d:
                break
            cible.sendall(d)
    except OSError:
        pass
    finally:
        for s in (source, cible):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


def analyser(tete):
    """(méthode, chemin, dict d'en-têtes) à partir du bloc décodé."""
    lignes = tete.split("\r\n")
    parties = lignes[0].split(" ")
    methode = parties[0] if parties else "GET"
    chemin = parties[1] if len(parties) > 1 else "/"
    entetes = {}
    for l in lignes[1:]:
        if ":" in l:
            k, v = l.split(":", 1)
            entetes[k.strip().lower()] = v.strip()
    return methode, chemin, entetes


class Lecteur:
    """Lecture tamponnée d'une socket : indispensable pour ne pas mordre sur la
    requête suivante quand plusieurs arrivent dans le même paquet."""

    def __init__(self, sock):
        self.sock = sock
        self.tampon = b""

    def jusqua(self, marque, maximum=MAX_ENTETE):
        while marque not in self.tampon:
            if len(self.tampon) > maximum:
                raise OSError("en-tête démesuré")
            d = self.sock.recv(65536)
            if not d:
                raise OSError("connexion fermée")
            self.tampon += d
        tete, self.tampon = self.tampon.split(marque, 1)
        return tete

    def exactement(self, n):
        while len(self.tampon) < n:
            d = self.sock.recv(65536)
            if not d:
                raise OSError("connexion fermée")
            self.tampon += d
        out, self.tampon = self.tampon[:n], self.tampon[n:]
        return out

    def ligne(self):
        return self.jusqua(b"\r\n", 65536)


def lire_corps(lecteur, entetes):
    """Le corps, quelle que soit sa forme de découpage."""
    if entetes.get("transfer-encoding", "").lower().find("chunked") >= 0:
        morceaux = []
        while True:
            taille_hex = lecteur.ligne().split(b";")[0].strip()
            n = int(taille_hex or b"0", 16)
            if n == 0:
                lecteur.jusqua(b"\r\n")  # remorque éventuelle
                break
            morceaux.append(lecteur.exactement(n))
            lecteur.exactement(2)
        return b"".join(morceaux)
    n = int(entetes.get("content-length") or 0)
    return lecteur.exactement(n) if n else b""


def reconstruire(methode, chemin, entetes, corps, hote_amont):
    """Réécrit la requête pour l'amont : en-têtes de bout en bout intacts,
    en-têtes de saut retirés, longueur recalculée."""
    lignes = ["%s %s HTTP/1.1" % (methode, chemin)]
    for k, v in entetes.items():
        if k in HOP_BY_HOP or k == "content-length":
            continue
        if k == "host":
            v = hote_amont
        lignes.append("%s: %s" % (k.title(), v))
    if "host" not in entetes:
        lignes.append("Host: %s" % hote_amont)
    lignes.append("Content-Length: %d" % len(corps))
    lignes.append("Connection: close")
    return ("\r\n".join(lignes) + "\r\n\r\n").encode("latin-1", "replace") + corps


class Poignee(socketserver.BaseRequestHandler):
    def handle(self):
        client = self.request
        client.settimeout(65)
        lecteur = Lecteur(client)

        while True:
            try:
                brut = lecteur.jusqua(b"\r\n\r\n")
            except OSError:
                return
            methode, chemin, entetes = analyser(brut.decode("latin-1", "replace"))

            # --- élévation WebSocket : on cesse de parler HTTP et on recopie ---
            if "upgrade" in entetes.get("connection", "").lower() or entetes.get("upgrade"):
                if PONT is not None:
                    # Devant o11-rebuild, un tunnel ne servirait à rien : l'amont
                    # n'a pas de `/ws`, et ses cinq canaux ne parlent pas la
                    # langue du panel. Le pont tient les deux bouts.
                    PONT.servir(client, chemin, entetes)
                else:
                    self.elever(client, brut + b"\r\n\r\n" + lecteur.tampon)
                return

            try:
                corps = lire_corps(lecteur, entetes)
            except OSError:
                return

            # Un appel authentifié qui traverse le panel porte le jeton dont
            # le moteur aura besoin quand plus personne ne sera là. On le
            # retient une fois — jamais on ne le journalise.
            if IDENT is not None and chemin.startswith("/api/") and entetes.get("authorization"):
                IDENT.retenir(entetes["authorization"])

            if chemin.split("?")[0] == "/__panel/epg-auto":
                garder = self.epg_auto(client, methode, chemin, entetes)
            elif chemin.split("?")[0] == "/__panel/capabilities":
                # Ce que le panel peut RÉELLEMENT faire derrière cet amont. Un
                # écran doit pouvoir griser un bouton avant le clic, plutôt que
                # de montrer un 501 après.
                garder = self.repondre_json(client, entetes, 200, capacites())
            elif ADAPTATEUR is not None and chemin.split("?")[0].startswith("/api/"):
                # La couche de compatibilité répond à la place de l'amont : le
                # panel continue d'appeler ses routes legacy sans le savoir.
                garder = self.traduire(client, chemin, entetes, corps)
            elif pour_amont(chemin):
                garder = self.relayer(client, methode, chemin, entetes, corps)
            else:
                garder = self.servir(client, methode, chemin, entetes)
            if not garder:
                return

    # ------------------------------------------------------------------
    def epg_auto(self, client, methode, chemin, entetes):
        """L'état de l'automatisation, et rien d'autre.

        Aucun jeton ne sort d'ici : on dit d'OÙ vient l'identifiant, jamais
        lequel. Un écran a besoin de savoir que le moteur tourne ; il n'a
        jamais besoin du secret qui le fait tourner.
        """
        if PLAN is None:
            return self.repondre_json(client, entetes, 200, {
                "actif": False,
                "motif": "auto EPG désactivé (O11_AUTO_EPG=0)"})

        if methode == "POST":
            # Une passe à la demande. Elle prend les MÊMES verrous que la
            # passe planifiée : demander une passe pendant qu'une tourne ne
            # lance pas la seconde, elle répond que la première tourne.
            q = urllib.parse.parse_qs(chemin.partition("?")[2]) if "?" in chemin else {}
            prov = (q.get("provider") or [""])[0] or None
            simuler = (q.get("simuler") or ["0"])[0] in ("1", "true", "yes")
            try:
                res = PLAN.cycle(provider=prov, simuler=simuler)
            except Exception as e:
                return self.repondre_json(client, entetes, 500, {
                    "actif": True, "motif": "passe interrompue : %s" % e})
            return self.repondre_json(client, entetes, 200, res)

        etat = {
            "mode": PLAN.mode,
            # Sans persistance, le moteur repart chaque fois d'un journal vide :
            # il ne remplace toujours AUCUN choix manuel — c'est le côté sûr —
            # mais il gèle aussi ses propres associations passées et cesse de
            # les entretenir. L'écran doit pouvoir le dire.
            "persistance": bool(ETAT_OK),
            "persistance_motif": ETAT_MOTIF,
            "intervalle": PLAN.intervalle,
            "identifiant": (IDENT.source if IDENT else "") or "aucun",
            "en_cours": sorted(PLAN.verrous.occupes().keys()),
            "dernier_cycle": PLAN.dernier_cycle,
            "passes": JOURNAL_EPG.derniere_passe() if JOURNAL_EPG else {},
            "seuil": MOTEUR.SEUIL if MOTEUR else None,
        }
        return self.repondre_json(client, entetes, 200, etat)

    def elever(self, client, premiers_octets):
        try:
            amont = socket.create_connection((AMONT_HOTE, AMONT_PORT), timeout=15)
        except OSError:
            return
        amont.settimeout(None)
        client.settimeout(None)
        amont.sendall(premiers_octets)
        threading.Thread(target=pomper, args=(client, amont), daemon=True).start()
        pomper(amont, client)

    def traduire(self, client, chemin, entetes, corps):
        try:
            code, objet = ADAPTATEUR.traiter(chemin, entetes, corps)
        except Exception as e:
            code, objet = 500, {"Code": 500, "Message": "adaptateur : %s" % e}
        return self.repondre_json(client, entetes, code, objet)

    def repondre_json(self, client, entetes, code, objet):
        charge = json.dumps(objet, ensure_ascii=False).encode()
        garder = entetes.get("connection", "").lower() != "close"
        tete = ("HTTP/1.1 %d %s\r\n"
                "Content-Type: application/json\r\n"
                "Content-Length: %d\r\n"
                "Connection: %s\r\n\r\n"
                % (code, "OK" if code < 400 else "Error", len(charge),
                   "keep-alive" if garder else "close"))
        try:
            client.sendall(tete.encode() + charge)
        except OSError:
            return False
        return garder

    def avec_session_amont(self, entetes):
        """Traduit le jeton legacy du panel en cookie de session o11-rebuild.

        Le navigateur ne détient PAS la session d'o11-rebuild : c'est la couche
        de compatibilité qui la garde, une par jeton distribué au panel. Sans
        cette traduction, `/output/` répond 401 alors que l'utilisateur est
        parfaitement authentifié — l'adresse serait exacte et ne jouerait pas.

        Aucun jeton n'est fabriqué et aucun n'est journalisé : on réutilise la
        session que l'utilisateur a déjà ouverte en se connectant.
        """
        jeton = (entetes.get("authorization") or "").strip()
        session = getattr(ADAPTATEUR, "sessions", {}).get(jeton)
        if session is None or not getattr(session, "jar", None):
            return entetes
        biscuits = "; ".join("%s=%s" % (c.name, c.value) for c in session.jar)
        if not biscuits:
            return entetes
        e = dict(entetes)
        e["cookie"] = (e["cookie"] + "; " + biscuits) if e.get("cookie") else biscuits
        return e

    def relayer(self, client, methode, chemin, entetes, corps):
        """Une requête vers l'amont, sa réponse rendue au client. La connexion
        cliente reste ouverte : le navigateur enchaîne ses requêtes dessus."""
        hote_amont = "%s:%d" % (AMONT_HOTE, AMONT_PORT)
        if ADAPTATEUR is not None and chemin.startswith("/output/"):
            entetes = self.avec_session_amont(entetes)
        try:
            amont = socket.create_connection((AMONT_HOTE, AMONT_PORT), timeout=20)
        except OSError as e:
            self.erreur(client, 502, '{"Code":502,"Message":"upstream unreachable: %s"}' % e)
            return False
        amont.settimeout(120)
        try:
            amont.sendall(reconstruire(methode, chemin, entetes, corps, hote_amont))
            la = Lecteur(amont)
            tete = la.jusqua(b"\r\n\r\n")
            statut, _, rep_entetes = analyser(tete.decode("latin-1", "replace"))
            # HEAD et 204/304 n'ont pas de corps, quoi qu'annoncent les en-têtes.
            code = 0
            try:
                code = int(tete.split(b"\r\n", 1)[0].split(b" ")[1])
            except (IndexError, ValueError):
                pass
            if methode == "HEAD" or code in (204, 304) or 100 <= code < 200:
                rep_corps = b""
            else:
                rep_corps = self.corps_reponse(la, rep_entetes, amont)
        except OSError as e:
            self.erreur(client, 502, '{"Code":502,"Message":"upstream error: %s"}' % e)
            return False
        finally:
            try:
                amont.close()
            except OSError:
                pass

        garder = entetes.get("connection", "").lower() != "close"
        lignes = [tete.split(b"\r\n", 1)[0].decode("latin-1", "replace")]
        for k, v in rep_entetes.items():
            if k in HOP_BY_HOP or k == "content-length":
                continue
            lignes.append("%s: %s" % (k.title(), v))
        lignes.append("Content-Length: %d" % len(rep_corps))
        lignes.append("Connection: %s" % ("keep-alive" if garder else "close"))
        try:
            client.sendall(("\r\n".join(lignes) + "\r\n\r\n").encode("latin-1", "replace") + rep_corps)
        except OSError:
            return False
        return garder

    def corps_reponse(self, lecteur, entetes, sock):
        """Le corps de la réponse amont, dans ses trois formes de découpage."""
        if "chunked" in entetes.get("transfer-encoding", "").lower():
            morceaux = []
            while True:
                n = int(lecteur.ligne().split(b";")[0].strip() or b"0", 16)
                if n == 0:
                    try:
                        lecteur.jusqua(b"\r\n")
                    except OSError:
                        pass
                    break
                morceaux.append(lecteur.exactement(n))
                lecteur.exactement(2)
            return b"".join(morceaux)
        if entetes.get("content-length") is not None:
            return lecteur.exactement(int(entetes["content-length"]))
        # Ni longueur ni découpage : le corps va jusqu'à la fermeture.
        out = [lecteur.tampon]
        lecteur.tampon = b""
        try:
            while True:
                d = sock.recv(65536)
                if not d:
                    break
                out.append(d)
        except OSError:
            pass
        return b"".join(out)

    # La raison qui accompagne le code. « 404 Bad Gateway » se lit mal dans un
    # journal, et se lit encore plus mal dans l'onglet réseau d'un navigateur.
    RAISONS = {400: "Bad Request", 404: "Not Found", 500: "Internal Server Error",
               502: "Bad Gateway", 504: "Gateway Timeout"}

    def erreur(self, client, code, corps):
        raison = self.RAISONS.get(code, "Error")
        try:
            client.sendall(
                ("HTTP/1.1 %d %s\r\nContent-Type: application/json\r\n"
                 "Content-Length: %d\r\nConnection: close\r\n\r\n"
                 % (code, raison, len(corps))).encode()
                + corps.encode()
            )
        except OSError:
            pass

    def servir(self, client, methode, chemin, entetes):
        nu = chemin.split("?")[0]
        # /static/assets/panel.js  ->  <dist>/assets/panel.js
        relatif = re.sub(r"^/static/", "/", nu).lstrip("/")
        fichier = os.path.normpath(os.path.join(RACINE, relatif))
        # On ne sert jamais hors de la racine, quoi que demande le client.
        if not fichier.startswith(RACINE) or not os.path.isfile(fichier):
            if est_fichier(nu):
                # Un fichier demandé, un fichier absent : on le DIT. Le repli
                # SPA est réservé aux routes de l'interface.
                self.erreur(client, 404,
                            '{"Code":404,"Message":"asset not found: %s"}' % nu)
                return False
            # Repli SPA : toute route inconnue rend la coquille, comme le binaire.
            fichier = os.path.join(RACINE, "index.html")
        try:
            with open(fichier, "rb") as f:
                corps = f.read()
        except OSError:
            self.erreur(client, 500, '{"Code":500,"Message":"panel files missing"}')
            return False

        ext = os.path.splitext(fichier)[1]
        garder = entetes.get("connection", "").lower() != "close"
        entier = len(corps)
        debut, fin = 0, entier - 1
        statut = "200 OK"
        supplement = ""

        # Une reprise de lecture (Range) doit fonctionner : c'est ce qui permet de
        # se déplacer dans une vidéo servie par le panel.
        plage = entetes.get("range", "")
        m = re.match(r"bytes=(\d*)-(\d*)$", plage)
        if m and entier:
            d = int(m.group(1)) if m.group(1) else None
            f = int(m.group(2)) if m.group(2) else None
            if d is None and f is not None:
                debut, fin = max(0, entier - f), entier - 1
            elif d is not None:
                debut, fin = d, (f if f is not None else entier - 1)
            fin = min(fin, entier - 1)
            if debut <= fin:
                corps = corps[debut:fin + 1]
                statut = "206 Partial Content"
                supplement = "Content-Range: bytes %d-%d/%d\r\n" % (debut, fin, entier)

        tete = (
            "HTTP/1.1 %s\r\n"
            "Content-Type: %s\r\n"
            "Content-Length: %d\r\n"
            "Accept-Ranges: bytes\r\n"
            "%s"
            "Cache-Control: %s\r\n"
            "Connection: %s\r\n\r\n"
            % (
                statut,
                TYPES.get(ext, "application/octet-stream"),
                len(corps),
                supplement,
                "no-cache" if ext == ".html" else "public, max-age=86400",
                "keep-alive" if garder else "close",
            )
        )
        try:
            client.sendall(tete.encode() + (b"" if methode == "HEAD" else corps))
        except OSError:
            return False
        return garder


class Serveur(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    if "--version" in sys.argv:
        print("o11-panel proxy %s" % VERSION)
        sys.exit(0)
    if not os.path.isdir(RACINE):
        print("panel introuvable : %s" % RACINE, file=sys.stderr)
        sys.exit(2)
    # Le libellé doit nommer l'amont RÉEL. Écrire « o11pro » devant un
    # o11-rebuild envoie chercher la panne du mauvais côté — et c'est
    # exactement la ligne qu'on relit en premier dans un journal.
    nom_amont = "o11-rebuild" if ADAPTATEUR is not None else "o11pro"
    print(
        "panel O11 %s : http://%s:%d  ->  %s %s:%d"
        % (VERSION, ECOUTE_HOTE, ECOUTE_PORT, nom_amont, AMONT_HOTE, AMONT_PORT),
        flush=True,
    )
    if ADAPTATEUR is not None:
        # Ce que l'amont dit de lui-même, au démarrage : une ligne qui évite
        # d'aller interroger `/__panel/capabilities` pour un simple doute.
        ident = ADAPTATEUR.identite_amont() or {}
        if ident.get("version"):
            print("  amont : %s %s (API %s, commit %s)"
                  % (ident.get("name") or "o11-rebuild", ident["version"],
                     ident.get("api_version") or "?", ident.get("commit") or "?"),
                  flush=True)
        else:
            print("  amont : injoignable pour l'instant — le panel démarre "
                  "quand même et réessaiera", flush=True)
    if PLAN is not None:
        PLAN.start()
        print("  auto EPG : mode %s, toutes les %d s%s"
              % (PLAN.mode, PLAN.intervalle,
                 "" if (IDENT and IDENT.jeton()) or PLAN.mode == "rebuild"
                 else " — en attente d'un identifiant de service"), flush=True)
        if not ETAT_OK:
            print("  auto EPG : ATTENTION, état non persistant (%s).\n"
                  "            Les associations du moteur seront gelées après\n"
                  "            chaque redémarrage. Ouvrir un chemin d'écriture :\n"
                  "              systemctl edit o11-panel  →  StateDirectory=o11-panel"
                  % ETAT_MOTIF, flush=True)
    Serveur((ECOUTE_HOTE, ECOUTE_PORT), Poignee).serve_forever()
