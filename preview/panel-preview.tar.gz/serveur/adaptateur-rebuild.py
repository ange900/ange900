#!/usr/bin/env python3
"""Couche de compatibilité : API legacy O11 Pro → o11-rebuild.

Le panel a été écrit pour O11 Pro : 75 routes toutes en POST, jeton brut dans
`Authorization`, un WebSocket unique. o11-rebuild est un autre logiciel : REST
avec les identifiants dans le chemin, session par cookie, cinq WebSockets.
Plutôt que de retoucher quatre-vingts fichiers d'interface, toute la traduction
tient ICI.

Trois règles tiennent ce fichier :

  1. **Une erreur reste une erreur.** Un amont qui répond 500 ne devient jamais
     une liste vide : l'écran doit dire pourquoi il n'a rien, pas faire semblant
     d'être vide. C'est le rôle d'`ErreurAdaptateur`.
  2. **Aucune valeur inventée.** Un réglage qui n'existe pas derrière est rendu
     à sa valeur neutre, jamais à une valeur plausible : un exploitant qui lit
     « 30 s » doit pouvoir croire que c'est vrai.
  3. **Rien ne s'écrit hors demande.** L'adaptateur ne crée ni compte, ni jeton,
     ni provider de son propre chef.

Les écarts mesurés sont dans `docs/ADAPTER_MAP.md`, `docs/CONFIG_GAP.md`,
`docs/KEYS_DRM_GAP.md` et `docs/ACCOUNTS_GAP.md`.
"""

import datetime
import http.cookiejar
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

VERSION_ADAPTATEUR = "1.1.0"

# --------------------------------------------------------------------- erreur


class ErreurAdaptateur(Exception):
    """Une erreur qui garde sa provenance jusqu'à l'écran.

    `amont` distingue ce qui vient d'o11-rebuild de ce que la couche a décidé
    elle-même. Sans cette distinction, un exploitant ne sait pas s'il doit
    regarder son serveur ou ce fichier."""

    def __init__(self, status, code, message, amont=None, route=""):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.amont = amont
        self.route = route

    def corps(self):
        """La forme d'erreur qu'attend le panel : {Code, Message}."""
        d = {"Code": self.status, "Message": self.message}
        if self.code:
            d["ErrorCode"] = self.code
        if self.amont:
            d["Upstream"] = self.amont
        if self.route:
            d["Route"] = self.route
        return d


# ------------------------------------------------------------------ formatage


def duree_go(secondes):
    """« 1h38m33s », comme le rend O11 Pro. Le panel affiche cette chaîne telle
    quelle ; la reformater changerait l'écran."""
    if not secondes or secondes < 0:
        return ""
    s = int(secondes)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    if h:
        return "%dh%dm%ds" % (h, m, s)
    if m:
        return "%dm%ds" % (m, s)
    return "%ds" % s


def debit(bps):
    if not bps:
        return ""
    if bps >= 1_000_000:
        return "%.1fMbps" % (bps / 1_000_000)
    if bps >= 1000:
        return "%.0fkbps" % (bps / 1000)
    return "%dbps" % bps


def _vise(brut):
    """L'identifiant de flux visé, la sentinelle « all » retirée.

    O11 Pro emploie `StreamId=all` pour dire « tous les flux » (c'est ce que
    l'écran Linear envoie sur son WebSocket streamstatus). Traité comme un
    identifiant, il ne correspondait à aucun flux et la liste sortait vide."""
    v = (brut or "").strip()
    return "" if v == "all" else v


def resolution_o11(res, fps=None):
    """La résolution au format d'O11 Pro : « 720p » (hauteur), « 720p25 » quand
    le nombre d'images est réellement annoncé. o11-rebuild rend le runtime en
    « largeurxhauteur » (ex. « 1280x720 ») et, depuis rc31, un `frame_rate`
    entier séparé quand la source l'annonce. On construit la hauteur, et on
    n'ajoute le « 25 » QUE si `fps` existe — jamais inventé.

    Une valeur déjà au format « 720p » / « 720p25 » est rendue telle quelle."""
    if not res:
        return ""
    r = str(res).strip()
    if re.match(r"^\d{3,4}p\d*$", r):        # déjà « 720p » ou « 720p25 »
        return r
    m = re.match(r"^(\d{2,5})x(\d{2,5})$", r)  # « 1280x720 » → « 720p »
    if m:
        label = m.group(2) + "p"
        try:
            n = int(fps)
        except (TypeError, ValueError):
            n = 0
        if n > 0:
            label += str(n)               # « 720p » → « 720p25 »
        return label
    return r


# ------------------------------------------------------------------ session


class Session:
    """Une session o11-rebuild, désignée au panel par un jeton de forme legacy."""

    def __init__(self, jar, utilisateur):
        self.jar = jar
        self.utilisateur = utilisateur
        self.identifiant = None      # id numérique côté o11-rebuild
        self.est_admin = False
        self.vue = time.time()
        self.providers = {}          # slug → id, cache court
        self.providers_vus = 0.0
        self.flux = {}               # (slug provider, slug flux) → id
        self.evenements = {}         # slug → id


class AdaptateurRebuild:
    # Réglages du panel dont o11-rebuild n'a pas l'équivalent : ils sont rendus
    # à leur valeur neutre, jamais à une valeur plausible.
    ABSENTES = {
        "/account/pair": "o11-rebuild n'a pas d'appairage d'opérateur : "
                         "émuler l'échange laisserait une session ouverte chez "
                         "l'opérateur sans personne pour la fermer.",
        "/account/export": "les comptes de script sont un SECRET dans "
                           "o11-rebuild : ils s'écrivent, ils ne se relisent pas.",
        "/account/import": "import de comptes non traduit : voir docs/ACCOUNTS_GAP.md.",
        "/account/login": "o11-rebuild ne pilote pas la connexion d'un compte d'opérateur.",
        "/account/disableall": "o11-rebuild n'a pas de notion d'activation par compte.",
        "/account/enableall": "o11-rebuild n'a pas de notion d'activation par compte.",
        "/account/deletedisabled": "o11-rebuild n'a pas de notion d'activation par compte.",
        "/provider/exportkeys": "o11-rebuild garde les clés de contenu en secret "
                                "chiffré : elles ne se relisent pas, donc ne "
                                "s'exportent pas.",
        "/provider/exportmanifestandkeys": "mêmes raisons que l'export de clés.",
        "/provider/pushkeys": "o11-rebuild n'accepte pas de clés poussées "
                              "depuis un autre serveur.",
        "/stream/flushkeys": "le cache de clés d'o11-rebuild n'est pas pilotable.",
        "/stream/refreshkeys": "le cache de clés d'o11-rebuild n'est pas pilotable.",
        "/stream/stoprefresh": "un rafraîchissement o11-rebuild n'est pas interruptible.",
        "/provider/cachelogos": "o11-rebuild ne pré-remplit pas son cache de "
                                "logos : il les récupère à la demande. Sa seule "
                                "route, DELETE /logos/cache, VIDE le cache — "
                                "brancher le bouton dessus ferait l'inverse de "
                                "ce qu'il annonce.",
        "/shutdown": "o11-rebuild n'expose aucune route d'arrêt — refus délibéré "
                     "de son auteur, pas un oubli de la couche.",
    }

    COULEURS = {
        "streaming": "green",
        "running": "orange",
        "starting": "orange",
        "stopping": "yellow",
        "error": "red",
        "stopped": "LightSteelBlue",
    }

    MODE_MARCHE = {"internal": "internalremuxer"}
    MODE_SORTIE = {"hls": "directhls", "ts": "ffmpeg"}
    RESEAU = {"direct": "", "proxy": "proxy", "same": "same"}
    NIVEAU = {"debug": 5, "info": 3, "warn": 2, "error": 1}
    NIVEAU_INV = {5: "debug", 4: "debug", 3: "info", 2: "warn", 1: "error", 0: "error"}

    def __init__(self, hote, port, journal=print):
        self.hote, self.port = hote, port
        self.base = "http://%s:%d" % (hote, port)
        self.journal = journal
        self.sessions = {}
        self.verrou = threading.Lock()
        self.jeton_lecture = None    # fourni par l'exploitant, jamais fabriqué
        # La version de l'amont se LIT ; elle ne se suppose pas. Le point
        # d'appui est `/api/v1/meta` — relevé dans les routes Go d'o11-rebuild,
        # avec `/api/v1/health` : ce sont les deux seules qui portent une
        # version, et les deux répondent sans session.
        # (`/api/v1/server/getinfo` n'existe pas : la route rend 404.)
        self._identite = {}
        self._identite_vue = 0.0

    # ------------------------------------------------------------------ amont
    def _appel(self, session, methode, chemin, charge=None, brut=False):
        """Un appel à o11-rebuild. Lève `ErreurAdaptateur` sur échec — c'est
        volontaire : un appelant ne peut pas confondre « rien » et « raté »."""
        jar = session.jar if session else http.cookiejar.CookieJar()
        ouvreur = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        donnees = json.dumps(charge).encode() if charge is not None else None
        req = urllib.request.Request(
            self.base + chemin, data=donnees, method=methode,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        try:
            with ouvreur.open(req, timeout=30) as r:
                contenu, code = r.read(), r.status
        except urllib.error.HTTPError as e:
            contenu, code = e.read(), e.code
        except Exception as e:
            raise ErreurAdaptateur(
                502, "upstream_unreachable",
                "o11-rebuild est injoignable : %s" % e, route=chemin)
        if brut:
            if code >= 400:
                raise ErreurAdaptateur(code, "upstream_error",
                                       contenu.decode("utf-8", "replace")[:400],
                                       route=chemin)
            return contenu
        try:
            objet = json.loads(contenu or b"{}")
        except ValueError:
            raise ErreurAdaptateur(502, "upstream_not_json",
                                   "o11-rebuild a répondu autre chose que du JSON.",
                                   route=chemin)
        if code >= 400:
            err = objet.get("error") or {}
            raise ErreurAdaptateur(
                code, err.get("code") or "upstream_error",
                err.get("message") or "o11-rebuild a refusé la requête.",
                amont=err, route=chemin)
        return objet

    def _liste(self, session, chemin):
        return self._appel(session, "GET", chemin).get("data") or []

    def _un(self, session, chemin):
        return self._appel(session, "GET", chemin).get("data") or {}

    # ------------------------------------------------------------- signature
    @staticmethod
    def signature(hote, port):
        """Reconnaît o11-rebuild à ce qu'il DÉCLARE, pas à son nom de processus
        — qui ne prouve rien — ni à son port, qui se change.

        On n'accepte pas « un JSON a répondu » : `health` doit porter un statut
        ET une version, ou `meta` une api_version v1 ET ses modules. Beaucoup de
        services rendent du JSON sur une route inconnue."""
        def lire(chemin):
            try:
                with urllib.request.urlopen(
                    "http://%s:%d%s" % (hote, port, chemin), timeout=4) as r:
                    return json.loads(r.read(32000)).get("data") or {}
            except Exception:
                return None

        sante = lire("/api/v1/health")
        if sante and sante.get("status") and sante.get("version"):
            return sante["version"]
        meta = lire("/api/v1/meta")
        if meta and meta.get("api_version") == "v1" and meta.get("modules"):
            return meta.get("version") or "?"
        return None

    # --------------------------------------------------------------- session
    def _session(self, entetes):
        jeton = (entetes.get("authorization") or "").strip()
        with self.verrou:
            s = self.sessions.get(jeton)
            if s:
                s.vue = time.time()
            return s

    def _exige(self, entetes, route):
        s = self._session(entetes)
        if s is None:
            raise ErreurAdaptateur(401, "unauthorized", "Unauthorized", route=route)
        return s

    def _ouvrir(self, utilisateur, motdepasse):
        jar = http.cookiejar.CookieJar()
        session = Session(jar, utilisateur)
        try:
            self._appel(session, "POST", "/api/v1/auth/login",
                        {"username": utilisateur, "password": motdepasse})
        except ErreurAdaptateur as e:
            if e.status in (400, 401, 403, 422):
                return None
            raise
        moi = self._un(session, "/api/v1/auth/me").get("user") or {}
        session.identifiant = moi.get("id")
        session.est_admin = moi.get("role") == "admin" or moi.get("is_admin", False)
        # Le panel attend un jeton opaque ; on en émet un et on garde la session
        # amont derrière. Le mot de passe n'est jamais conservé.
        jeton = secrets.token_urlsafe(32)
        with self.verrou:
            self.sessions[jeton] = session
        return jeton

    # ------------------------------------------------------- résolution d'id
    def _providers(self, session):
        """slug → provider complet. o11-rebuild numérote, le panel nomme."""
        if time.time() - session.providers_vus < 5 and session.providers:
            return session.providers
        liste = self._liste(session, "/api/v1/providers?per_page=500")
        session.providers = {(p.get("slug") or str(p.get("id"))): p for p in liste}
        session.providers_vus = time.time()
        return session.providers

    def _id_provider(self, session, slug, route):
        if slug in (None, "", "all"):
            return None
        p = self._providers(session).get(str(slug))
        if p is None:
            raise ErreurAdaptateur(404, "provider_not_found",
                                   "Provider inconnu : %s" % slug, route=route)
        return p["id"]

    def _flux_du_provider(self, session, id_provider, type_flux=None):
        q = "/api/v1/streams?per_page=1000"
        if id_provider:
            q += "&provider_id=%d" % id_provider
        if type_flux:
            q += "&type=%s" % urllib.parse.quote(type_flux)
        liste = self._liste(session, q)
        for s in liste:
            session.flux[(s.get("provider_slug"), s.get("slug"))] = s["id"]
        return liste

    def _id_flux(self, session, slug_provider, slug_flux, route):
        cle = (str(slug_provider), str(slug_flux))
        if cle in session.flux:
            return session.flux[cle]
        idp = self._id_provider(session, slug_provider, route)
        self._flux_du_provider(session, idp)
        if cle not in session.flux:
            raise ErreurAdaptateur(404, "stream_not_found",
                                   "Flux inconnu : %s" % slug_flux, route=route)
        return session.flux[cle]

    # ----------------------------------------------------------- traductions
    def _url_lecture(self, s):
        """Les adresses de lecture, dans la forme legacy [{Url, Quality, …}].

        Sans jeton de lecture fourni par l'exploitant, l'adresse est rendue SANS
        `access_token` : elle est exacte mais ne joue pas. Fabriquer un jeton
        serait écrire un secret sans qu'on nous l'ait demandé."""
        # Adresse RELATIVE, et c'est important : une adresse absolue vers
        # l'amont (`http://127.0.0.1:8485/output/...`) sort de l'origine du
        # panel. Le navigateur court-circuite alors le relais, n'attache aucun
        # jeton, et o11-rebuild répond 401 — l'adresse serait « exacte » et ne
        # jouerait jamais. En relatif, la requête passe par le panel, qui y
        # remet la session de l'utilisateur.
        base = "/output/streams/%s/index.m3u8" % s.get("id")
        if self.jeton_lecture:
            base += "?access_token=" + urllib.parse.quote(self.jeton_lecture)
        return [{"Url": base, "Quality": "", "Bw": 0, "Resolution": "",
                 "Codecs": "", "Audio": "", "Default": True}]

    def _flux_vers_config(self, s, niveau_journal=3):
        """Un flux o11-rebuild rendu dans les 92 champs qu'attend l'écran Config.

        Les champs sans équivalent gardent leur valeur neutre. Le tableau des
        correspondances est dans `docs/CONFIG_GAP.md` : 55 champs se traduisent,
        29 sont devenus automatiques, 143 n'existent pas."""
        r = s.get("settings") or {}
        secrets_ = s.get("configured_secrets") or []
        variante = r.get("variant_selection") or ""
        video = variante if variante in ("best", "worst") else (
            "%dp" % r["preferred_height"] if r.get("preferred_height") else "")
        return {
            # — traduits —
            "Id": s.get("slug") or str(s.get("id")),
            "Name": s.get("name", ""),
            "Type": s.get("type", "linear"),
            "LogoUrl": s.get("logo_url", ""),
            "Category": s.get("group_title", ""),
            "Description": s.get("description", ""),
            "EpgId": s.get("epg_channel_id", ""),
            "SortId": s.get("sort_index", 0),
            "Manifest": s.get("source_url", ""),
            "RunningMode": self.MODE_MARCHE.get(s.get("running_mode"), ""),
            "OutputMode": self.MODE_SORTIE.get(s.get("output_mode"), ""),
            "Autostart": bool(r.get("autostart", False)),
            "OnDemand": bool(r.get("on_demand", False)),
            "SpeedUp": bool(r.get("speed_up", False)),
            "IgnoreUpdate": bool(r.get("ignore_update", False)),
            "DailyOnAir": bool(r.get("daily_on_air", False)),
            "RecordTs": bool(r.get("record_ts", False)),
            "ProcessDVBSubs": bool(r.get("process_dvb_subs", False)),
            "ModeOverride": bool(r.get("network_override", False)),
            "NetworkOverride": bool(r.get("network_override", False)),
            "UseCdm": bool(r.get("use_cdm", False)),
            "ScriptParams": r.get("script_params", ""),
            "Video": video,
            "Audio": r.get("audio_track", ""),
            "LogLevel": niveau_journal,
            "HasKeys": "content_keys" in secrets_,
            "HasManifest": bool(s.get("source_url")),
            "StreamingUrl": self._url_lecture(s),
            # — valeurs neutres : le réglage n'existe pas derrière —
            "AudioList": [], "VideoList": [], "SubtitlesList": [],
            "Subtitles": "", "SubtitlesOffset": 0,
            "AutorestartCron": "", "Cdn": None, "CdnName": "",
            "CdmMode": "", "CdmType": "",
            "DailyStartTime": "", "DailyEndTime": "",
            "Drm": None, "Heartbeat": None, "License": None,
            "Start": 0, "End": 0, "TimeRange": "",
            "EpgNow": "", "EpgNext": "", "EpgNowStart": 0, "EpgNowEnd": 0,
            "ExtraStatus": "", "Info": "",
            "FirstAudioTrack": "", "FirstSubtitlesTrack": "",
            "HasInternalDrm": False, "HwAccelDeviceIndex": 0,
            # Les secrets d'o11-rebuild s'écrivent mais ne se relisent pas :
            # rendre un objet vide dit la vérité, pas une valeur d'apparence.
            "Headers": {"Manifest": {}, "Media": {}, "HlsKey": {}},
            "Keys": "", "LegacyId": "",
            "ManifestBind": "", "ManifestDns": "", "ManifestDoh": "",
            "ManifestExpiration": 0, "ManifestInfo": "", "ManifestInfo2": None,
            "ManifestNetwork": "", "ManifestProxy": "", "ManifestType": "",
            "ManifestWorker": "", "ManualEvent": False,
            "MediaBind": "", "MediaDns": "", "MediaDoh": "",
            "MediaNetwork": "", "MediaProxy": "", "MediaWorker": "",
            "OriginalLogoUrl": "",
            "PRClientVersion": "", "PRCustomData": "", "PRLAVersion": "",
            "PipeOutputParams": "", "ProtoOutputParams": "",
            "RecordEvent": False, "ScriptAccountsUser": "",
            "ScriptBind": "", "ScriptDns": "", "ScriptDoh": "",
            "ScriptNetwork": "", "ScriptProxy": "", "ScriptWorker": "",
            "SessionManifest": False,
            "StreamingResolutions": [],
        }

    def _flux_vers_statut(self, s, etat):
        """Les 27 champs de la trame de statut legacy."""
        st = (etat or {}).get("status") or "stopped"
        actif = bool((etat or {}).get("running"))
        diffuse = bool((etat or {}).get("is_streaming"))
        haut = duree_go((etat or {}).get("uptime_seconds"))
        # `last_error` est un OBJET côté o11-rebuild — {code, message, at} —, là
        # où le panel attend une phrase. Ranger le dict tel quel afficherait du
        # JSON brut dans la carte du flux.
        brut = (etat or {}).get("last_error")
        erreur = (brut.get("message") or brut.get("code") or "") if isinstance(brut, dict) \
            else (brut or "")
        texte = {"streaming": "Streaming\n%s\n" % haut,
                 "starting": "Starting", "stopping": "Stopping",
                 "running": "Running", "error": erreur or "Error",
                 "stopped": "Stopped"}.get(st, st)
        res = (etat or {}).get("resolution")
        secrets_ = s.get("configured_secrets") or []
        return {
            "Id": s.get("slug") or str(s.get("id")),
            "Name": s.get("name", ""),
            "Type": s.get("type", "linear"),
            "LogoUrl": s.get("logo_url", ""),
            "Status": texte,
            "StatusColor": self.COULEURS.get(st, "LightSteelBlue"),
            "StreamInfo": ("Video:\n%s\n" % res) if res else "",
            "StreamErrors": erreur,
            "Running": actif,
            "IsStreaming": diffuse,
            "Uptime": haut,
            "Bw": debit((etat or {}).get("input_bandwidth_bps")),
            "ConnectedClients": (etat or {}).get("connected_clients") or 0,
            "HasManifest": bool(s.get("source_url")),
            "HasKeys": "content_keys" in secrets_,
            "StreamingUrl": self._url_lecture(s),
            "StreamingResolutions": [resolution_o11(res, (etat or {}).get("frame_rate"))] if res else [],
            "PChangeCounter": (etat or {}).get("restarts", 0),
            # Sans équivalent : neutre, jamais inventé.
            "AdInProgress": False, "ScriptUser": "",
            "CurrentManifestParams": "",
            "CurrentManifestNetParam": "", "CurrentManifestNetValue": "",
            "CurrentMediaNetParam": "", "CurrentMediaNetValue": "",
            "CurrentScriptNetParam": "", "CurrentScriptNetValue": "",
        }

    def _provider_vers_legacy(self, p):
        r = p.get("settings") or {}
        return {
            "Id": p.get("slug") or str(p.get("id")),
            "Name": p.get("name", ""),
            "LogoUrl": p.get("logo_url", ""),
            "StreamsCount": p.get("stream_count", 0),
            "Streams": None,
            "Script": p.get("name", "") if p.get("type") == "script" else "",
            # Les 16 réglages réellement présents des deux côtés.
            "ChannelsRefreshCron": r.get("channels_refresh_cron", ""),
            "EpgRefreshCron": r.get("epg_refresh_cron", ""),
            "EventsRefreshCron": r.get("events_refresh_cron", ""),
            "EpgTimezone": r.get("epg_timezone", ""),
            "HttpGetRetries": r.get("http_retries", 0),
            "HttpGetTimeout": r.get("http_timeout_s", 0),
            "MaxConcurrentStreams": r.get("max_concurrent_streams", 0),
            "MaxDownloadConcurrency": r.get("download_concurrency", 0),
            "PlaylistDuration": r.get("playlist_duration_s", 0),
            "RestartDelay": r.get("restart_delay_s", 0),
            "StallDetectTimeout": r.get("stall_detect_timeout_s", 0),
            "UseSessionCookies": bool(r.get("use_session_cookies", False)),
            "UserAgent": r.get("user_agent", ""),
            "ManifestNetwork": self.RESEAU.get(r.get("manifest_network"), ""),
            "MediaNetwork": self.RESEAU.get(r.get("media_network"), ""),
            "ScriptNetwork": self.RESEAU.get(r.get("script_network"), ""),
            # Sans équivalent : neutre.
            "RunningMode": "", "OutputMode": "",
            "ChannelsAutorefresh": False,
            "Headers2": {"Manifest": {}, "Media": {}, "HlsKey": {}},
            "ScriptAccounts": None,
        }

    def _niveau_journal(self, session):
        try:
            reglages = self._un(session, "/api/v1/settings").get("settings") or []
        except ErreurAdaptateur:
            return 3
        for r in reglages:
            if r.get("key") == "logging.level":
                return self.NIVEAU.get(r.get("value"), 3)
        return 3

    # ------------------------------------------------------------ événements
    def _evenements(self, session, id_provider, route):
        """Un événement legacy = un événement o11-rebuild JOINT à son flux.

        o11-rebuild sépare les deux : la programmation d'un côté, le flux qui la
        diffuse de l'autre. Le panel les attend fusionnés."""
        q = "/api/v1/events?per_page=500"
        if id_provider:
            q += "&provider_id=%d" % id_provider
        evs = self._liste(session, q)
        flux = {s["id"]: s for s in self._flux_du_provider(session, id_provider)}
        for e in evs:
            session.evenements[e.get("provider_slug", "") + "/" + str(e.get("id"))] = e["id"]
        return evs, flux


    # =====================================================================
    #                              ROUTAGE
    # =====================================================================
    def traiter(self, chemin, entetes, corps):
        """(code, objet JSON) pour une requête legacy.

        Une seule porte : toute erreur repart dans la forme {Code, Message} que
        le panel sait lire, avec le message de l'amont quand il y en a un."""
        route = chemin.split("?")[0][len("/api"):]
        try:
            charge = json.loads(corps or b"{}")
        except ValueError:
            charge = {}
        if not isinstance(charge, dict):
            charge = {}
        try:
            return self._router(route, entetes, charge)
        except ErreurAdaptateur as e:
            return e.status, e.corps()
        except Exception as e:                          # pragma: no cover
            self.journal("adaptateur: %s sur %s" % (e, route))
            return 500, ErreurAdaptateur(
                500, "adapter_error",
                "Erreur interne de la couche de compatibilité : %s" % e,
                route=route).corps()

    def _router(self, route, entetes, charge):
        for prefixe, raison in self.ABSENTES.items():
            if route.startswith(prefixe):
                raise ErreurAdaptateur(501, "not_in_rebuild", raison, route=route)

        if route == "/login":
            jeton = self._ouvrir(charge.get("Username", ""), charge.get("Password", ""))
            if not jeton:
                raise ErreurAdaptateur(401, "invalid_credentials",
                                       "invalid user or password", route=route)
            return 200, {"Token": jeton}

        s = self._exige(entetes, route)
        f = getattr(self, "r_" + route.strip("/").replace("/", "_"), None)
        if f is None:
            raise ErreurAdaptateur(
                501, "not_translated",
                "Route non traduite par la couche de compatibilité o11-rebuild : "
                "%s (voir docs/ADAPTER_MAP.md)" % route, route=route)
        return f(s, charge, route)

    # ------------------------------------------------------------ bootstrap
    def r_bootstrap(self, s, c, route):
        """Le panel demande de quoi s'amorcer. On lui dit ce qu'IL peut faire,
        pas ce qu'O11 Pro savait faire."""
        return 200, {
            "Version": self._un(s, "/api/v1/meta").get("version", ""),
            "UpstreamKind": "rebuild",
            "Adapter": VERSION_ADAPTATEUR,
            "MassUpdateActions": None,
        }

    # ------------------------------------------------------------ providers
    def r_provider_get(self, s, c, route):
        vise = c.get("ProviderId") or ""
        out = []
        for slug, p in sorted(self._providers(s).items()):
            if vise and slug != vise:
                continue
            out.append(self._provider_vers_legacy(p))
        return 200, {"Providers": out or None}

    def r_provider_add(self, s, c, route):
        p = c.get("Provider") or c
        nom = p.get("Name") or c.get("ProviderName") or ""
        if not nom:
            raise ErreurAdaptateur(422, "missing_name",
                                   "Un provider doit avoir un nom.", route=route)
        d = self._appel(s, "POST", "/api/v1/providers",
                        {"name": nom, "type": "static",
                         "logo_url": p.get("LogoUrl", "")})
        s.providers_vus = 0
        return 200, {"Code": 200, "Message": "success",
                     "ProviderId": (d.get("data") or {}).get("slug", "")}

    # Les réglages de provider qui existent des deux côtés. Tout ce qui n'est
    # pas ici est ignoré à l'écriture, et l'appelant en est informé.
    REGLAGES_PROVIDER = {
        "ChannelsRefreshCron": ("channels_refresh_cron", str),
        "EpgRefreshCron": ("epg_refresh_cron", str),
        "EventsRefreshCron": ("events_refresh_cron", str),
        "EpgTimezone": ("epg_timezone", str),
        "HttpGetRetries": ("http_retries", int),
        "HttpGetTimeout": ("http_timeout_s", int),
        "MaxConcurrentStreams": ("max_concurrent_streams", int),
        "MaxDownloadConcurrency": ("download_concurrency", int),
        "PlaylistDuration": ("playlist_duration_s", int),
        "RestartDelay": ("restart_delay_s", int),
        "StallDetectTimeout": ("stall_detect_timeout_s", int),
        "UseSessionCookies": ("use_session_cookies", bool),
        "UserAgent": ("user_agent", str),
    }

    def r_provider_edit(self, s, c, route):
        slug = c.get("ProviderId") or ""
        # DEUX formes de charge, toutes deux réelles et toutes deux acceptées par
        # le binaire : l'écran Config envoie `{ProviderId, Provider:{…144 champs}}`,
        # l'écran Providers envoie À PLAT `{ProviderId, ProviderName, LogoBase64}`
        # pour un simple renommage.
        # Ne lire que la première faisait répondre « success, Written: 0 » à un
        # renommage qui n'avait rien renommé — un succès qui ment, trouvé par le
        # banc Providers et pas par la relecture.
        p = dict(c.get("Provider") or {})
        if c.get("ProviderName"):
            p["Name"] = c["ProviderName"]
        if c.get("LogoUrl"):
            p["LogoUrl"] = c["LogoUrl"]
        idp = self._id_provider(s, slug, route)
        reglages, ignores = {}, []
        for cle, valeur in p.items():
            corr = self.REGLAGES_PROVIDER.get(cle)
            if corr is None:
                if cle not in ("Id", "Name", "LogoUrl", "Streams", "StreamsCount"):
                    ignores.append(cle)
                continue
            nom, typ = corr
            try:
                reglages[nom] = typ(valeur)
            except (TypeError, ValueError):
                ignores.append(cle)
        corps = {}
        if p.get("Name"):
            corps["name"] = p["Name"]
        if "LogoUrl" in p:
            corps["logo_url"] = p["LogoUrl"]
        if reglages:
            corps["settings"] = reglages
        self._appel(s, "PATCH", "/api/v1/providers/%d" % idp, corps)
        s.providers_vus = 0
        # On compte TOUT ce qu'on a écrit — l'identité comme les réglages.
        # Ne compter que les réglages faisait annoncer « Written: 0 » à un
        # renommage qui avait bien eu lieu : un compte faux, dans l'autre sens.
        ecrits = len(reglages) + sum(1 for k in ("name", "logo_url") if k in corps)
        return 200, self._succes_partiel(ecrits, ignores)

    def r_provider_delete(self, s, c, route):
        idp = self._id_provider(s, c.get("ProviderId"), route)
        self._appel(s, "DELETE", "/api/v1/providers/%d" % idp)
        s.providers_vus = 0
        return 200, {"Code": 200, "Message": "success"}

    def r_provider_backup(self, s, c, route):
        self._appel(s, "POST", "/api/v1/backup", {})
        return 200, {"Code": 200, "Message": "success"}

    def r_provider_rescan(self, s, c, route):
        d = self._appel(s, "POST", "/api/v1/provider-directory/scan", {})
        s.providers_vus = 0
        return 200, {"Code": 200, "Message": "success",
                     "Report": d.get("data")}

    @staticmethod
    def _succes_partiel(ecrits, ignores):
        """Un succès qui dit ce qu'il n'a PAS fait.

        « 200 success » sur une requête à moitié appliquée est le mensonge que
        cette couche doit éviter : l'exploitant croirait avoir réglé quelque
        chose."""
        d = {"Code": 200, "Message": "success", "Written": ecrits}
        if ignores:
            d["Ignored"] = sorted(ignores)
            d["Message"] = ("success — %d réglage(s) enregistré(s), %d sans "
                            "équivalent dans o11-rebuild et ignoré(s)"
                            % (ecrits, len(ignores)))
        return d

    # ---------------------------------------------------------------- flux
    def _flux_pour(self, s, slug_provider, type_flux, route):
        """Les flux d'un provider (ou de tous), du type demandé.

        Le type legacy et le type o11-rebuild portent les mêmes noms —
        `linear`, `event`, `vod` —, ce qui est une chance : le piège
        `linear`→`channel` ne concerne que les CHEMINS de rafraîchissement."""
        idp = self._id_provider(s, slug_provider, route)
        return self._flux_du_provider(s, idp, type_flux or None)

    def r_stream_get(self, s, c, route):
        type_flux = c.get("StreamType") or ""
        # « all » est la sentinelle « tous les flux » d'O11 Pro, PAS un
        # identifiant : la traiter comme un id filtrait tout — c'est ce que
        # l'écran Linear envoie sur son WebSocket streamstatus (StreamId=all).
        vise = _vise(c.get("StreamId"))
        flux = self._flux_pour(s, c.get("ProviderId"), type_flux, route)
        niveau = self._niveau_journal(s)
        out = []
        for x in flux:
            slug = x.get("slug") or str(x.get("id"))
            if vise and slug != vise:
                continue
            # La liste ne porte pas les réglages complets : on relit la fiche.
            fiche = self._un(s, "/api/v1/streams/%d" % x["id"]) or x
            out.append(self._flux_vers_config(fiche, niveau))
        return 200, {"Streams": out, "HasEpg": any(x.get("epg_mapped") for x in flux)}

    def r_stream_status(self, s, c, route):
        type_flux = c.get("StreamType") or ""
        # « all » = tous les flux (sentinelle O11 Pro), pas un identifiant.
        vise = _vise(c.get("StreamId"))
        motif = (c.get("SearchPattern") or "").lower()
        filtre = (c.get("Filter") or "").lower()
        slug_p = c.get("ProviderId") or ""
        # `linear,event` est une charge réelle : l'écran Recordings la passe.
        types = [t for t in type_flux.split(",") if t] or [None]
        par_provider = {}
        for t in types:
            for x in self._flux_pour(s, slug_p, t, route):
                par_provider.setdefault(x.get("provider_slug"), []).append(x)
        sortie = []
        for slug, flux in sorted(par_provider.items()):
            p = self._providers(s).get(slug) or {}
            lignes = []
            for x in flux:
                sx = x.get("slug") or str(x.get("id"))
                if vise and sx != vise:
                    continue
                if motif and motif not in (x.get("name", "") + sx).lower():
                    continue
                # Le runtime est DÉJÀ dans la liste (`/streams` l'enrichit avec
                # les mêmes métriques de sortie que `/streams/{id}/status` —
                # même `etatSortie` côté serveur). Le relire flux par flux
                # faisait N appels HTTP par trame : sur un provider à 100+
                # chaînes, chaque rafraîchissement streamstatus prenait plusieurs
                # secondes, et l'écran Linear semblait « ne pas repartir » après
                # un Start jusqu'au F5. On lit le runtime de la liste : UN appel.
                etat = x.get("runtime") or {}
                ligne = self._flux_vers_statut(x, etat)
                if filtre == "running" and not ligne["Running"]:
                    continue
                if filtre == "stopped" and ligne["Running"]:
                    continue
                if filtre == "error" and ligne["StatusColor"] != "red":
                    continue
                lignes.append(ligne)
            if c.get("SortAlpha"):
                lignes.sort(key=lambda l: l["Name"].lower())
            sortie.append({"Id": slug, "Name": p.get("name", slug),
                           "HasEpg": any(x.get("epg_mapped") for x in flux),
                           "Streams": lignes})
        return 200, {"Providers": sortie}

    def _cibles(self, s, c, route):
        """Les flux visés par une action, sentinelles comprises.

        `autostart` et `onair` ne sont pas des identifiants : O11 Pro les
        interprète comme « tous ceux marqués ainsi ». o11-rebuild n'a pas cette
        commande groupée ; on la déroule ici, ce qui est la même chose vue de
        l'écran, et honnête vue du serveur."""
        slug_p = c.get("ProviderId") or ""
        sid = c.get("StreamId") or ""
        type_flux = c.get("StreamType") or ""
        if sid in ("autostart", "onair"):
            flux = self._flux_pour(s, slug_p, type_flux or None, route)
            cle = "autostart" if sid == "autostart" else "daily_on_air"
            return [x for x in flux if (x.get("settings") or {}).get(cle)]
        if not sid:
            return self._flux_pour(s, slug_p, type_flux or None, route)
        idp = self._id_provider(s, slug_p, route)
        for x in self._flux_du_provider(s, idp, type_flux or None):
            if (x.get("slug") or str(x.get("id"))) == sid:
                return [x]
        # Un événement est désigné par son EventId, pas par le slug du flux.
        if type_flux == "event":
            for e in self._liste(s, "/api/v1/events?per_page=500"):
                if str(e.get("id")) == str(sid) and e.get("stream_id"):
                    fiche = self._un(s, "/api/v1/streams/%d" % e["stream_id"])
                    if fiche:
                        return [fiche]
        raise ErreurAdaptateur(404, "stream_not_found",
                               "Flux inconnu : %s" % sid, route=route)

    def _action_flux(self, s, c, route, verbe):
        cibles = self._cibles(s, c, route)
        faits, refus = 0, []
        for x in cibles:
            try:
                self._appel(s, "POST", "/api/v1/streams/%d/%s" % (x["id"], verbe), {})
                faits += 1
            except ErreurAdaptateur as e:
                refus.append("%s : %s" % (x.get("name", x["id"]), e.message))
        if faits == 0 and refus:
            raise ErreurAdaptateur(502, "upstream_error", " ; ".join(refus), route=route)
        d = {"Code": 200, "Message": "success", "Affected": faits}
        if refus:
            d["Message"] = "success partiel — %d sur %d ; %s" % (
                faits, len(cibles), " ; ".join(refus))
        return 200, d

    def r_stream_start(self, s, c, route):
        return self._action_flux(s, c, route, "start")

    def r_stream_stop(self, s, c, route):
        return self._action_flux(s, c, route, "stop")

    def r_stream_refresh(self, s, c, route):
        return self._action_flux(s, c, route, "manifest-refresh")

    def r_stream_delete(self, s, c, route):
        idf = self._id_flux(s, c.get("ProviderId"), c.get("StreamId"), route)
        self._appel(s, "DELETE", "/api/v1/streams/%d" % idf)
        s.flux.pop((str(c.get("ProviderId")), str(c.get("StreamId"))), None)
        return 200, {"Code": 200, "Message": "success"}

    def r_stream_add(self, s, c, route):
        idp = self._id_provider(s, c.get("ProviderId"), route)
        x = c.get("Stream") or {}
        nom = c.get("StreamName") or x.get("Name") or ""
        if not nom:
            raise ErreurAdaptateur(422, "missing_name",
                                   "Un flux doit avoir un nom.", route=route)
        corps = {"provider_id": idp, "name": nom,
                 "type": x.get("Type") or "linear",
                 "source_url": x.get("Manifest", ""),
                 "logo_url": x.get("LogoUrl", ""),
                 "description": x.get("Description", "")}
        d = self._appel(s, "POST", "/api/v1/streams", corps)
        s.flux.clear()
        return 200, {"Code": 200, "Message": "success",
                     "StreamId": (d.get("data") or {}).get("slug", "")}

    # Les réglages de flux qui existent des deux côtés.
    REGLAGES_FLUX = {
        "Autostart": ("autostart", bool),
        "OnDemand": ("on_demand", bool),
        "SpeedUp": ("speed_up", bool),
        "IgnoreUpdate": ("ignore_update", bool),
        "DailyOnAir": ("daily_on_air", bool),
        "RecordTs": ("record_ts", bool),
        "ProcessDVBSubs": ("process_dvb_subs", bool),
        "NetworkOverride": ("network_override", bool),
        "ModeOverride": ("mode_override", bool),
        "UseCdm": ("use_cdm", bool),
        "ScriptParams": ("script_params", str),
        "Audio": ("audio_track", str),
    }
    CHAMPS_FLUX = {
        "Name": "name", "LogoUrl": "logo_url", "Description": "description",
        "Manifest": "source_url", "EpgId": "epg_channel_id", "SortId": "sort_index",
    }

    def r_stream_edit(self, s, c, route):
        idf = self._id_flux(s, c.get("ProviderId"), c.get("StreamId"), route)
        x = c.get("Stream") or {}
        corps, reglages, ignores = {}, {}, []
        for cle, valeur in x.items():
            if cle in self.CHAMPS_FLUX:
                corps[self.CHAMPS_FLUX[cle]] = valeur
                continue
            corr = self.REGLAGES_FLUX.get(cle)
            if corr is None:
                if cle in ("Id", "Type", "StreamingUrl", "HasKeys", "HasManifest",
                           "Category", "StreamingResolutions"):
                    continue        # lecture seule des deux côtés
                ignores.append(cle)
                continue
            nom, typ = corr
            try:
                reglages[nom] = typ(valeur)
            except (TypeError, ValueError):
                ignores.append(cle)
        if x.get("Video"):
            v = str(x["Video"])
            if v in ("best", "worst"):
                reglages["variant_selection"] = v
            else:
                m = re.match(r"^(\d+)p?$", v)
                if m:
                    reglages["variant_selection"] = "height"
                    reglages["preferred_height"] = int(m.group(1))
        if reglages:
            corps["settings"] = reglages
        fiche = self._un(s, "/api/v1/streams/%d" % idf)
        corps["version"] = fiche.get("version", 0)
        self._appel(s, "PATCH", "/api/v1/streams/%d" % idf, corps)
        s.flux.clear()
        return 200, self._succes_partiel(len(corps) - 1 + len(reglages), ignores)

    # --------------------------------------------------------- événements
    def r_event_refreshrequest(self, s, c, route):
        return self._action_flux(s, dict(c, StreamType="event", StreamId=""),
                                 route, "manifest-refresh")

    def r_channel_refreshrequest(self, s, c, route):
        return self._action_flux(s, dict(c, StreamType="linear", StreamId=""),
                                 route, "manifest-refresh")

    def r_vod_refreshrequest(self, s, c, route):
        return self._action_flux(s, dict(c, StreamType="vod", StreamId=""),
                                 route, "manifest-refresh")

    def _applique_directement(self, route):
        raise ErreurAdaptateur(
            501, "no_two_phase_refresh",
            "o11-rebuild applique un rafraîchissement immédiatement : il n'a pas "
            "la prévisualisation en deux temps d'O11 Pro. La demande a déjà été "
            "appliquée ; il n'y a rien à confirmer.", route=route)

    r_channel_refreshapply = lambda self, s, c, r: self._applique_directement(r)
    r_event_refreshapply = lambda self, s, c, r: self._applique_directement(r)
    r_vod_refreshapply = lambda self, s, c, r: self._applique_directement(r)
    r_epg_refreshapply = lambda self, s, c, r: self._applique_directement(r)

    # --------------------------------------------------------------- EPG
    def r_epg_get(self, s, c, route):
        """Le guide, dans la forme que l'écran EPG attend.

        o11-rebuild sépare ce qu'O11 Pro fusionne : ses programmes sont
        rattachés à une CHAÎNE DU GUIDE, pas à un flux, et sa route exige un
        `channel_id`. La jonction flux ↔ chaîne se lit dans les associations du
        provider — c'est elle qui donne le nom affiché."""
        slug_p = c.get("ProviderId") or ""
        idp = self._id_provider(s, slug_p, route)
        cibles = [idp] if idp else [p["id"] for p in self._providers(s).values()]
        motif = (c.get("SearchPattern") or "").lower()

        flux = {x["id"]: x for x in self._flux_du_provider(s, idp)}
        entrees, jours = [], set()
        for pid in cibles:
            assoc = self._un(s, "/api/v1/providers/%d/epg-mappings" % pid)
            for m in assoc.get("mappings") or []:
                if not m.get("mapped") or not m.get("channel_id"):
                    continue
                x = flux.get(m.get("stream_id")) or {}
                q = "/api/v1/epg/programmes?limit=500&channel_id=%d" % m["channel_id"]
                if motif:
                    q += "&search=" + urllib.parse.quote(c["SearchPattern"])
                for pr in self._liste(s, q):
                    debut = self._epoque(pr.get("start_at") or "")
                    jours.add(time.strftime("%Y-%m-%d", time.localtime(debut)) if debut else "")
                    entrees.append({
                        "ChannelName": m.get("stream_name", ""),
                        "EpgId": m.get("tvg_id", ""),
                        "StreamId": x.get("slug") or str(m.get("stream_id", "")),
                        "StreamType": x.get("type", "linear"),
                        "Title": pr.get("title", ""),
                        "Description": pr.get("description", ""),
                        "Lang": pr.get("lang", ""),
                        "Start": debut,
                        "End": self._epoque(pr.get("end_at") or ""),
                    })
        if c.get("DateFilter"):
            entrees = [e for e in entrees
                       if time.strftime("%Y-%m-%d", time.localtime(e["Start"])) == c["DateFilter"]]
        entrees.sort(key=lambda e: (e["Start"], e["ChannelName"]))
        return 200, {"Entries": entrees,
                     "AvailableDates": sorted(d for d in jours if d)}

    @staticmethod
    def _epoque(iso):
        """Un horodatage ISO 8601 en secondes Unix. Zéro si illisible — le
        panel sait afficher « — » sur un zéro, il ne sait rien faire d'une date
        inventée."""
        if not iso:
            return 0
        t = iso.strip().replace("Z", "+00:00")
        # Go rend jusqu'à neuf décimales ; datetime en accepte six.
        m = re.match(r"^(.*\.\d{6})\d*(.*)$", t)
        if m:
            t = m.group(1) + m.group(2)
        try:
            return int(datetime.datetime.fromisoformat(t).timestamp())
        except ValueError:
            return 0

    def r_epg_refresh(self, s, c, route):
        sources = self._liste(s, "/api/v1/epg/sources")
        if not sources:
            raise ErreurAdaptateur(
                404, "no_epg_source",
                "Aucune source EPG active dans o11-rebuild : rien à rafraîchir.",
                route=route)
        for src in sources:
            self._appel(s, "POST", "/api/v1/epg/sources/%d/refresh" % src["id"], {})
        return 200, {"Code": 200, "Message": "success", "Affected": len(sources)}

    r_epg_refreshrequest = r_epg_refresh

    # ----------------------------------------------------------- journaux
    def r_log_get(self, s, c, route):
        d = self._un(s, "/api/v1/logs?limit=2000")
        lignes = []
        for e in d.get("entries") or []:
            attrs = " ".join("%s=%s" % (k, v) for k, v in sorted((e.get("attrs") or {}).items()))
            lignes.append(("%s %-5s %s %s" % (
                e.get("time", "")[:23], (e.get("level") or "").upper(),
                e.get("message", ""), attrs)).rstrip())
        # `User`/`Password` servent au panel à composer une adresse de lecture.
        # o11-rebuild n'a pas d'empreinte de mot de passe dans ses URL : rendre
        # une valeur ici fabriquerait un secret.
        return 200, {"Logs": "\n".join(lignes), "User": s.utilisateur,
                     "Password": "", "StreamType": c.get("StreamType", "")}

    def r_log_export(self, s, c, route):
        code, d = 200, self.r_log_get(s, c, route)[1]
        return code, d

    def r_log_clean(self, s, c, route):
        self._appel(s, "POST", "/api/v1/logs/clear", {})
        return 200, {"Code": 200, "Message": "success"}

    def r_log_getconf(self, s, c, route):
        return 200, {"LogLevel": self._niveau_journal(s), "Filter": "",
                     "HighlightFilter": False}

    def r_log_setconf(self, s, c, route):
        niveau = c.get("LogLevel")
        if niveau is None:
            raise ErreurAdaptateur(422, "missing_level",
                                   "LogLevel est requis.", route=route)
        self._appel(s, "PUT", "/api/v1/settings",
                    {"values": {"logging.level": self.NIVEAU_INV.get(int(niveau), "info")}})
        ignores = [k for k in ("Filter", "HighlightFilter") if c.get(k)]
        return 200, self._succes_partiel(1, ignores)

    # -------------------------------------------------------------- tâches
    #
    # Deux mondes différents. O11 Pro planifie des SCRIPTS par expression cron ;
    # o11-rebuild planifie TROIS travaux connus, à une cadence en secondes. On
    # traduit ce qui se traduit et on refuse le reste en le nommant — un job
    # accepté puis jamais exécuté serait pire qu'un refus.
    TYPES_JOB = {
        "epg": "epg.refresh", "epgrefresh": "epg.refresh", "epg.refresh": "epg.refresh",
        "vod": "vod.probe", "vodprobe": "vod.probe", "vod.probe": "vod.probe",
        "manifest": "manifest.refresh", "manifestrefresh": "manifest.refresh",
        "manifest.refresh": "manifest.refresh",
    }
    CRON_FIXE = {"@hourly": 3600, "@daily": 86400, "@midnight": 86400,
                 "@weekly": 604800, "@every_minute": 60}

    def _cadence(self, cron, route):
        """Une expression cron en secondes, quand c'est possible SANS deviner.

        Les formes régulières se convertissent exactement. « 30 4 * * 1 » — tous
        les lundis à 4 h 30 — n'est pas une cadence : c'est une heure de
        rendez-vous, et o11-rebuild ne sait pas en tenir."""
        c = (cron or "").strip().lower()
        if c in self.CRON_FIXE:
            return self.CRON_FIXE[c]
        m = re.match(r"^\*/(\d+) \* \* \* \*$", c)
        if m:
            return max(60, int(m.group(1)) * 60)
        m = re.match(r"^0 \*/(\d+) \* \* \*$", c)
        if m:
            return int(m.group(1)) * 3600
        raise ErreurAdaptateur(
            501, "cron_not_supported",
            "o11-rebuild planifie à une CADENCE (toutes les N secondes), pas à "
            "une expression cron. « %s » désigne une heure de rendez-vous, qu'il "
            "ne sait pas tenir. Les formes convertibles sont @hourly, @daily, "
            "@weekly, « */N * * * * » et « 0 */N * * * »." % cron, route=route)

    def _type_job(self, j, route):
        brut = (j.get("Type") or j.get("ScriptName") or "").strip().lower()
        t = self.TYPES_JOB.get(brut.replace("_", "").replace("-", ""))
        if t:
            return t
        raise ErreurAdaptateur(
            501, "job_type_not_supported",
            "o11-rebuild ne connaît que trois travaux — epg.refresh, vod.probe "
            "et manifest.refresh — et n'exécute aucun script. « %s » n'a pas "
            "d'équivalent." % (brut or "(sans type)"), route=route)

    def r_job_add(self, s, c, route):
        j = c.get("Job") or {}
        typ = self._type_job(j, route)
        cadence = self._cadence(j.get("Cron"), route)
        cible = j.get("TargetId") or j.get("ProviderId")
        corps = {"type": typ, "interval_seconds": cadence}
        if cible is not None:
            try:
                corps["target_id"] = int(cible)
            except (TypeError, ValueError):
                corps["target_id"] = self._id_provider(s, cible, route)
        d = self._appel(s, "POST", "/api/v1/job-schedules", corps)
        ignores = [k for k in ("Name", "Description", "ScriptParams", "ScriptTimeout")
                   if j.get(k)]
        rep = self._succes_partiel(2, ignores)
        rep["JobId"] = (d.get("data") or {}).get("id")
        return 200, rep

    def r_job_edit(self, s, c, route):
        j = c.get("Job") or {}
        if not j.get("Id"):
            raise ErreurAdaptateur(422, "missing_id", "Id est requis.", route=route)
        courant = None
        for x in self._liste(s, "/api/v1/job-schedules"):
            if str(x.get("id")) == str(j["Id"]):
                courant = x
                break
        if courant is None:
            raise ErreurAdaptateur(404, "job_not_found",
                                   "Tâche inconnue : %s" % j["Id"], route=route)
        corps = {"version": courant.get("version", 0)}
        if j.get("Cron"):
            corps["interval_seconds"] = self._cadence(j["Cron"], route)
        if "Enabled" in j:
            corps["enabled"] = bool(j["Enabled"])
        ignores = [k for k in ("Name", "Description", "ScriptName", "ScriptParams",
                               "ScriptTimeout") if j.get(k)]
        self._appel(s, "PATCH", "/api/v1/job-schedules/%s" % j["Id"], corps)
        return 200, self._succes_partiel(len(corps) - 1, ignores)

    def r_job_delete(self, s, c, route):
        self._appel(s, "DELETE", "/api/v1/job-schedules/%s" % c.get("Id", ""))
        return 200, {"Code": 200, "Message": "success"}

    def r_job_run(self, s, c, route):
        """Le panel envoie l'identifiant d'une PLANIFICATION ; o11-rebuild lance
        un travail par son TYPE. On lit donc la planification pour savoir quoi
        lancer, plutôt que de deviner."""
        for x in self._liste(s, "/api/v1/job-schedules"):
            if str(x.get("id")) == str(c.get("Id")):
                corps = {"type": x.get("type")}
                if x.get("target_id") is not None:
                    corps["target_id"] = x["target_id"]
                d = self._appel(s, "POST", "/api/v1/jobs", corps)
                return 200, {"Code": 200, "Message": "success",
                             "JobId": (d.get("data") or {}).get("id")}
        raise ErreurAdaptateur(404, "job_not_found",
                               "Tâche inconnue : %s" % c.get("Id"), route=route)

    # ----------------------------------------------------- enregistrements
    ETAT_REC = {"recording": ("recording", "red"), "completed": ("completed", "green"),
                "failed": ("failed", "red"), "scheduled": ("scheduled", "white"),
                "stopped": ("stopped", "white")}

    def r_recording_get(self, s, c, route):
        slug_p = c.get("ProviderId") or ""
        recs = self._liste(s, "/api/v1/recordings?per_page=500")
        out = []
        for r in recs:
            if slug_p and r.get("provider_slug") != slug_p:
                continue
            etat, couleur = self.ETAT_REC.get(r.get("state"), (r.get("state", ""), "white"))
            out.append({
                "Id": str(r.get("id")),
                "Status": etat, "StatusColor": couleur,
                "ProviderId": r.get("provider_slug", ""),
                "ProviderName": r.get("provider_name", ""),
                "StreamId": str(r.get("stream_id", "")),
                "StreamName": r.get("stream_name", ""),
                "VideoId": r.get("filename", ""), "VideoDesc": "",
                "StreamingUrl": "%s/api/v1/recordings/%s/download" % (self.base, r.get("id")),
                "Start": self._epoque(r.get("started_at") or ""),
                "End": self._epoque(r.get("ended_at") or ""),
                "Title": r.get("name", ""), "Description": "",
            })
        return 200, {"Recordings": out}

    def r_recording_add(self, s, c, route):
        idf = self._id_flux(s, c.get("ProviderId"), c.get("StreamId"), route)
        self._appel(s, "POST", "/api/v1/recordings",
                    {"stream_id": idf, "name": c.get("Title") or "",
                     "start_stream": False})
        return 200, {"Code": 200, "Message": "success"}

    def r_recording_stop(self, s, c, route):
        self._appel(s, "POST", "/api/v1/recordings/%s/stop" % c.get("RecordingId", ""), {})
        return 200, {"Code": 200, "Message": "success"}

    def r_recording_delete(self, s, c, route):
        self._appel(s, "DELETE", "/api/v1/recordings/%s" % c.get("RecordingId", ""))
        return 200, {"Code": 200, "Message": "success"}

    def r_recording_edit(self, s, c, route):
        if not c.get("Id"):
            raise ErreurAdaptateur(422, "missing_id", "Id est requis.", route=route)
        corps = {}
        if "Title" in c:
            corps["name"] = c["Title"]
        ignores = [k for k in c if k not in ("Id", "Title", "ProviderId", "StreamId")]
        self._appel(s, "PATCH", "/api/v1/recordings/%s" % c["Id"], corps)
        return 200, self._succes_partiel(len(corps), ignores)

    r_replay_delete = r_recording_delete

    # ----------------------------------------------------- utilisateurs
    def r_user_get(self, s, c, route):
        try:
            liste = self._liste(s, "/api/v1/users?per_page=200")
        except ErreurAdaptateur as e:
            if e.status != 403:
                raise
            # Un non-admin ne voit que lui-même : c'est la règle d'o11-rebuild,
            # pas une panne.
            liste = [(self._un(s, "/api/v1/auth/me").get("user") or {})]
        return 200, {"Users": [{
            "Username": u.get("username", ""),
            "Password": "",
            "Network": ", ".join(u.get("allowed_networks") or []),
            "IsAdmin": bool(u.get("is_admin") or u.get("role") == "admin"),
            "HasWebAccess": bool(u.get("web_access", True)),
            # `ProviderIds: []` veut dire « aucun provider » côté O11 Pro.
            # o11-rebuild note « * » pour « tous » : on ne confond pas les deux.
            "ProviderIds": [] if u.get("provider_permissions") == ["*"]
                           else [str(x) for x in (u.get("provider_permissions") or [])],
            "AllProviders": u.get("provider_permissions") == ["*"],
        } for u in liste]}

    def r_user_add(self, s, c, route):
        self._appel(s, "POST", "/api/v1/users",
                    {"username": c.get("Username", ""),
                     "password": c.get("Password", ""),
                     "role": "admin" if c.get("IsAdmin") else "operator",
                     "web_access": bool(c.get("HasWebAccess", True))})
        return 200, {"Code": 200, "Message": "success"}

    def _id_utilisateur(self, s, nom, route):
        for u in self._liste(s, "/api/v1/users?per_page=200"):
            if u.get("username") == nom:
                return u["id"]
        raise ErreurAdaptateur(404, "user_not_found",
                               "Utilisateur inconnu : %s" % nom, route=route)

    def r_user_edit(self, s, c, route):
        idu = self._id_utilisateur(s, c.get("Username", ""), route)
        corps = {"role": "admin" if c.get("IsAdmin") else "operator",
                 "web_access": bool(c.get("HasWebAccess", True))}
        if c.get("Password"):
            corps["password"] = c["Password"]
        ignores = [k for k in ("Network", "ProviderIds") if c.get(k)]
        self._appel(s, "PATCH", "/api/v1/users/%d" % idu, corps)
        return 200, self._succes_partiel(len(corps), ignores)

    def r_user_delete(self, s, c, route):
        idu = self._id_utilisateur(s, c.get("Username", ""), route)
        self._appel(s, "DELETE", "/api/v1/users/%d" % idu)
        return 200, {"Code": 200, "Message": "success"}

    # --------------------------------------------------------- serveurs
    def r_server_get(self, s, c, route):
        return 200, {"Servers": [{
            "Id": str(x.get("id")), "Name": x.get("name", ""),
            "Url": x.get("base_url") or x.get("url") or "",
            "User": "", "Password": "",
        } for x in self._liste(s, "/api/v1/servers")] or None}

    def r_server_getinfo(self, s, c, route):
        meta = self._un(s, "/api/v1/meta")
        tab = self._un(s, "/api/v1/dashboard")
        flux = tab.get("streams") or {}
        prov = tab.get("providers") or {}
        return 200, {
            "Version": meta.get("version", ""),
            "Uptime": duree_go((tab.get("system") or {}).get("process_uptime_seconds")),
            "ProvidersCount": prov.get("total", 0),
            "StreamsCount": flux.get("total", 0),
            "RunningCount": flux.get("running", 0),
            "ErrorCount": flux.get("error", 0),
            "StreamPort": self.port,
        }

    def r_server_add(self, s, c, route):
        self._appel(s, "POST", "/api/v1/servers",
                    {"name": c.get("Name", ""), "type": "agent"})
        ignores = [k for k in ("Url", "User", "Password") if c.get(k)]
        return 200, self._succes_partiel(1, ignores)

    def r_server_edit(self, s, c, route):
        if not c.get("Id"):
            raise ErreurAdaptateur(422, "missing_id", "Id est requis.", route=route)
        self._appel(s, "PATCH", "/api/v1/servers/%s" % c["Id"], {"name": c.get("Name", "")})
        ignores = [k for k in ("Url", "User", "Password") if c.get(k)]
        return 200, self._succes_partiel(1, ignores)

    def r_server_delete(self, s, c, route):
        self._appel(s, "DELETE", "/api/v1/servers/%s" % c.get("Id", ""))
        return 200, {"Code": 200, "Message": "success"}

    # ------------------------------------------------------- capacités
    def _lire(self, chemin, taille=32000):
        """Une lecture SANS session : `health` et `meta` répondent à tout le
        monde, et c'est ce qui permet de les interroger avant toute connexion."""
        try:
            with urllib.request.urlopen(self.base + chemin, timeout=5) as r:
                return json.loads(r.read(taille)).get("data") or {}
        except Exception:
            return None

    def identite_amont(self):
        """Ce qu'o11-rebuild dit de lui-même, relu au plus une fois par minute.

        Deux sources, dans cet ordre — ce sont les seules routes de son code Go
        qui portent une version, et les seules qui répondent sans session :

          · `/api/v1/health` : version, commit, build_date, status, base ;
          · `/api/v1/meta`   : version, api_version, nom, modules.

        `/api/v1/server/getinfo` n'existe pas : la route rend 404. Et on ne lit
        NI un fichier d'installation — il vieillit sur place, on l'a vu annoncer
        rc29 devant un binaire rc30 —, NI les octets du binaire : la seule
        source de vérité est le processus qui répond."""
        if self._identite and time.time() - self._identite_vue < 60:
            return self._identite
        ident = {}
        sante = self._lire("/api/v1/health")
        if sante:
            for cle in ("version", "commit", "build_date", "status"):
                if sante.get(cle):
                    ident[cle] = sante[cle]
        meta = self._lire("/api/v1/meta")
        if meta:
            ident.setdefault("version", meta.get("version"))
            for source, cible in (("api_version", "api_version"), ("name", "name")):
                if meta.get(source):
                    ident[cible] = meta[source]
            mods = meta.get("modules") or []
            if mods:
                ident["modules"] = sorted(
                    m.get("key") for m in mods if isinstance(m, dict) and m.get("key"))
        if ident.get("version"):
            self._identite, self._identite_vue = ident, time.time()
        return ident or self._identite

    @property
    def version_amont(self):
        """La version d'o11-rebuild. `None` si elle n'a pas pu être lue — et
        rendue telle quelle plutôt que « ? », qui ressemblait à une version et
        n'en était pas une."""
        return (self.identite_amont() or {}).get("version")

    def capacites(self):
        """Ce que le panel peut réellement faire derrière cet amont.

        Sert `/__panel/capabilities` : un écran doit pouvoir désactiver un
        bouton AVANT que l'exploitant clique dessus, plutôt que de lui montrer
        un 501 après coup."""
        traduites = sorted(
            "/" + n[2:].replace("_", "/")
            for n in dir(self) if n.startswith("r_") and callable(getattr(self, n)))
        ident = self.identite_amont() or {}
        return {
            "upstream_kind": "rebuild",
            "adapter_version": VERSION_ADAPTATEUR,
            # Tout ce bloc vient du serveur qui tourne. Rien n'y est inscrit en
            # dur : une version écrite à la main devient fausse au premier
            # déploiement, et personne ne s'en aperçoit.
            "upstream_version": ident.get("version"),
            "upstream_api_version": ident.get("api_version"),
            "upstream_name": ident.get("name"),
            "upstream_commit": ident.get("commit"),
            "upstream_build_date": ident.get("build_date"),
            "upstream_status": ident.get("status"),
            # Les modules qu'o11-rebuild déclare. Ils servent à VALIDER ce que
            # la couche croit pouvoir traduire — pas à remplacer les traductions
            # déjà éprouvées, dont la valeur est justement dans les DTO.
            "upstream_modules": ident.get("modules"),
            "routes_translated": traduites,
            "routes_absent": sorted(self.ABSENTES),
            "playback_urls": "token" if self.jeton_lecture else "no_token",
            "config_fields": {"translated": 55, "automatic": 29, "absent": 143},
            "notes": [
                "Les secrets d'o11-rebuild s'écrivent mais ne se relisent jamais.",
                "Un rafraîchissement s'applique immédiatement : pas de deux temps.",
                "Sans jeton de lecture fourni, les adresses de lecture sont "
                "exactes mais ne jouent pas.",
            ],
        }
